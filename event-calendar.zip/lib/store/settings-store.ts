import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { ThemeType, PrimaryColorType, WeekStartsOnType, ViewType } from "@/lib/types"

interface SettingsState {
  is24HourFormat: boolean
  theme: ThemeType
  primaryColor: PrimaryColorType
  weekStartsOn: WeekStartsOnType
  defaultView: ViewType
  defaultDuration: number

  // Actions
  toggleTimeFormat: () => void
  setTheme: (theme: ThemeType) => void
  toggleTheme: () => void
  setPrimaryColor: (color: PrimaryColorType) => void
  setWeekStartsOn: (day: WeekStartsOnType) => void
  setDefaultView: (view: ViewType) => void
  setDefaultDuration: (minutes: number) => void
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      is24HourFormat: true,
      theme: "light",
      primaryColor: "blue",
      weekStartsOn: "monday",
      defaultView: "month",
      defaultDuration: 60,

      toggleTimeFormat: () => set((state) => ({ is24HourFormat: !state.is24HourFormat })),

      setTheme: (theme) => set({ theme }),

      toggleTheme: () =>
        set((state) => ({
          theme: state.theme === "light" ? "dark" : "light",
        })),

      setPrimaryColor: (primaryColor) => set({ primaryColor }),

      setWeekStartsOn: (weekStartsOn) => set({ weekStartsOn }),

      setDefaultView: (defaultView) => set({ defaultView }),

      setDefaultDuration: (defaultDuration) => set({ defaultDuration }),
    }),
    {
      name: "calendar-settings",
    },
  ),
)

