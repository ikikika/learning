import { create } from "zustand"
import type { ViewType, MonthData, CalendarViewData } from "@/lib/types"
import { generateMonthData, getMonthName, getNextMonth, getPrevMonth, getWeekDates } from "@/lib/date-utils"
import { useEventStore } from "./event-store"
import { useSettingsStore } from "./settings-store"

interface CalendarState {
  currentDate: Date
  viewType: ViewType
  monthData: MonthData

  // Actions
  setCurrentDate: (date: Date) => void
  setViewType: (viewType: ViewType) => void
  navigatePrevious: () => void
  navigateNext: () => void
  navigateToday: () => void
  setMonthData: (monthData: MonthData) => void
  generateMonthData: (year: number, month: number) => MonthData
  getViewTitle: () => string

  // Computed
  calendarViewData: CalendarViewData
}

export const useCalendarStore = create<CalendarState>((set, get) => ({
  currentDate: new Date(2025, 3, 1), // April 2025
  viewType: "month",
  monthData: generateMonthData(2025, 3),

  setCurrentDate: (date) => set({ currentDate: date }),

  setViewType: (viewType) => set({ viewType }),

  navigatePrevious: () => {
    const { currentDate, viewType } = get()

    if (viewType === "day") {
      const newDate = new Date(currentDate)
      newDate.setDate(currentDate.getDate() - 1)
      set({ currentDate: newDate })
    } else if (viewType === "week") {
      const newDate = new Date(currentDate)
      newDate.setDate(currentDate.getDate() - 7)
      set({ currentDate: newDate })
    } else {
      const { year, month } = getPrevMonth(currentDate.getFullYear(), currentDate.getMonth())
      set({ currentDate: new Date(year, month, 1) })
    }
  },

  navigateNext: () => {
    const { currentDate, viewType } = get()

    if (viewType === "day") {
      const newDate = new Date(currentDate)
      newDate.setDate(currentDate.getDate() + 1)
      set({ currentDate: newDate })
    } else if (viewType === "week") {
      const newDate = new Date(currentDate)
      newDate.setDate(currentDate.getDate() + 7)
      set({ currentDate: newDate })
    } else {
      const { year, month } = getNextMonth(currentDate.getFullYear(), currentDate.getMonth())
      set({ currentDate: new Date(year, month, 1) })
    }
  },

  navigateToday: () => set({ currentDate: new Date() }),

  setMonthData: (monthData) => set({ monthData }),

  generateMonthData: (year, month) => {
    const { weekStartsOn } = useSettingsStore.getState()
    const weekStartsOnNum = weekStartsOn === "monday" ? 1 : weekStartsOn === "sunday" ? 0 : 6
    return generateMonthData(year, month, weekStartsOnNum)
  },

  getViewTitle: () => {
    const { currentDate, viewType } = get()

    if (viewType === "day") {
      return `${currentDate.getDate()} ${getMonthName(currentDate.getMonth())} ${currentDate.getFullYear()}`
    } else if (viewType === "week") {
      const { weekStartsOn } = useSettingsStore.getState()
      const weekStartsOnNum = weekStartsOn === "monday" ? 1 : weekStartsOn === "sunday" ? 0 : 6
      const weekDates = getWeekDates(currentDate, weekStartsOnNum)
      const weekStart = weekDates[0]
      const weekEnd = weekDates[6]

      if (weekStart.getMonth() === weekEnd.getMonth()) {
        return `${weekStart.getDate()} - ${weekEnd.getDate()} ${getMonthName(weekStart.getMonth())} ${weekStart.getFullYear()}`
      } else if (weekStart.getFullYear() === weekEnd.getFullYear()) {
        return `${weekStart.getDate()} ${getMonthName(weekStart.getMonth())} - ${weekEnd.getDate()} ${getMonthName(weekEnd.getMonth())} ${weekStart.getFullYear()}`
      } else {
        return `${weekStart.getDate()} ${getMonthName(weekStart.getMonth())} ${weekStart.getFullYear()} - ${weekEnd.getDate()} ${getMonthName(weekEnd.getMonth())} ${weekEnd.getFullYear()}`
      }
    } else if (viewType === "agenda") {
      return `${getMonthName(currentDate.getMonth())} ${currentDate.getFullYear()}`
    } else {
      return `${getMonthName(currentDate.getMonth())} ${currentDate.getFullYear()}`
    }
  },

  get calendarViewData() {
    const { currentDate, monthData } = get()
    const { events, handleEventClick, handleAddEvent } = useEventStore.getState()
    const { is24HourFormat } = useSettingsStore.getState()

    return {
      currentDate,
      events,
      monthData,
      is24HourFormat,
      onEventClick: handleEventClick,
      onAddEvent: handleAddEvent,
    }
  },
}))

