"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Clock, Filter, Plus } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import type { EventData } from "@/lib/types"
import { EVENTS_DATA } from "@/lib/data"

export function CalendarDemo() {
  const [currentMonth, setCurrentMonth] = useState("April")
  const [currentYear, setCurrentYear] = useState(2025)
  const [viewMode, setViewMode] = useState("month")
  const [events] = useState<EventData>(EVENTS_DATA)

  const handlePrevMonth = () => {
    // In a real implementation, this would properly handle month/year changes
    setCurrentMonth("March")
  }

  const handleNextMonth = () => {
    // In a real implementation, this would properly handle month/year changes
    setCurrentMonth("May")
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle>Event Calendar</CardTitle>
        <div className="absolute top-4 right-4">
          <Button variant="ghost" size="icon" className="rounded-full">
            <span className="sr-only">Toggle theme</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <circle cx="12" cy="12" r="4"></circle>
              <path d="M12 2v2"></path>
              <path d="M12 20v2"></path>
              <path d="M4.93 4.93l1.41 1.41"></path>
              <path d="M17.66 17.66l1.41 1.41"></path>
              <path d="M2 12h2"></path>
              <path d="M20 12h2"></path>
              <path d="M6.34 17.66l-1.41 1.41"></path>
              <path d="M19.07 4.93l-1.41 1.41"></path>
            </svg>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" onClick={handlePrevMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center space-x-1">
                <div className="relative w-24">
                  <select
                    className="w-full appearance-none bg-transparent py-1 pl-2 pr-8 border border-input rounded-md"
                    value={currentMonth}
                    onChange={(e) => setCurrentMonth(e.target.value)}
                  >
                    <option>April</option>
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2">
                    <ChevronDown className="h-4 w-4 opacity-50" />
                  </div>
                </div>
                <div className="relative w-20">
                  <select
                    className="w-full appearance-none bg-transparent py-1 pl-2 pr-8 border border-input rounded-md"
                    value={currentYear}
                    onChange={(e) => setCurrentYear(Number.parseInt(e.target.value))}
                  >
                    <option>2025</option>
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2">
                    <ChevronDown className="h-4 w-4 opacity-50" />
                  </div>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={handleNextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" className="h-8">
                <Clock className="mr-2 h-4 w-4" />
                24h
              </Button>
              <Button variant="outline" size="sm" className="h-8">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
              <Button variant="outline" size="sm" className="h-8">
                This Month
              </Button>
              <div className="flex border rounded-md">
                <Button variant="ghost" size="sm" className="h-8 px-2 border-r">
                  <ListIcon className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 px-2 border-r">
                  <ColumnsIcon className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 px-2 border-r">
                  <GridIcon className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 px-2">
                  <LayoutGridIcon className="h-4 w-4" />
                </Button>
              </div>
              <Button className="bg-black text-white hover:bg-gray-800">
                <Plus className="mr-2 h-4 w-4" />
                Add Event
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
              <div key={day} className="text-center py-2 font-medium">
                {day}
              </div>
            ))}

            {Array.from({ length: 35 }, (_, i) => {
              const day = i + 1
              const dayEvents = events[day] || []

              return (
                <div key={i} className={cn("border min-h-[120px] p-1 relative", day > 30 && "opacity-50")}>
                  <div className="absolute top-1 left-2 font-medium">{day <= 30 ? day : day - 30}</div>
                  <div className="mt-6 space-y-1">
                    <AnimatePresence>
                      {dayEvents.slice(0, 2).map((event, idx) => (
                        <motion.div
                          key={`${day}-${idx}`}
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, height: 0 }}
                          className={cn(
                            "text-xs p-1 rounded",
                            event.color === "yellow" && "bg-yellow-100",
                            event.color === "green" && "bg-green-100",
                            event.color === "purple" && "bg-purple-100",
                            event.color === "red" && "bg-red-100",
                            event.color === "blue" && "bg-blue-100",
                          )}
                        >
                          <div className="font-medium">{event.title}</div>
                          {event.time && <div>{event.time}</div>}
                        </motion.div>
                      ))}
                    </AnimatePresence>

                    {dayEvents.length > 2 && (
                      <div className="text-xs text-center text-muted-foreground">+{dayEvents.length - 2} more</div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ChevronDown(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m6 9 6 6 6-6" />
    </svg>
  )
}

function ListIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="8" x2="21" y1="6" y2="6" />
      <line x1="8" x2="21" y1="12" y2="12" />
      <line x1="8" x2="21" y1="18" y2="18" />
      <line x1="3" x2="3.01" y1="6" y2="6" />
      <line x1="3" x2="3.01" y1="12" y2="12" />
      <line x1="3" x2="3.01" y1="18" y2="18" />
    </svg>
  )
}

function ColumnsIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
      <line x1="12" x2="12" y1="3" y2="21" />
    </svg>
  )
}

function GridIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
      <line x1="3" x2="21" y1="9" y2="9" />
      <line x1="3" x2="21" y1="15" y2="15" />
      <line x1="9" x2="9" y1="3" y2="21" />
      <line x1="15" x2="15" y1="3" y2="21" />
    </svg>
  )
}

function LayoutGridIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="7" height="7" x="3" y="3" rx="1" />
      <rect width="7" height="7" x="14" y="3" rx="1" />
      <rect width="7" height="7" x="14" y="14" rx="1" />
      <rect width="7" height="7" x="3" y="14" rx="1" />
    </svg>
  )
}

