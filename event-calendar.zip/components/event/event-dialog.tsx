"use client"

import { useEffect, useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import type { CalendarEvent } from "@/lib/types"
import { useEventStore } from "@/lib/store/event-store"
import { useSettingsStore } from "@/lib/store/settings-store"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { CalendarIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { RecurrenceOptions } from "./recurrence-options"

export function EventDialog() {
  const { isAddEventDialogOpen, closeAddEventDialog, selectedDate, selectedEvent, saveEvent } = useEventStore()

  const { is24HourFormat } = useSettingsStore()

  const [title, setTitle] = useState("")
  const [startDate, setStartDate] = useState<Date | undefined>(undefined)
  const [endDate, setEndDate] = useState<Date | undefined>(undefined)
  const [startTime, setStartTime] = useState("09:00")
  const [endTime, setEndTime] = useState("10:00")
  const [color, setColor] = useState<"yellow" | "green" | "purple" | "red" | "blue">("blue")
  const [description, setDescription] = useState("")
  const [location, setLocation] = useState("")
  const [allDay, setAllDay] = useState(false)
  const [timezone, setTimezone] = useState("local")
  const [recurrence, setRecurrence] = useState("none")
  const [activeTab, setActiveTab] = useState("details")

  // Reset form when dialog opens with new data
  useEffect(() => {
    if (isAddEventDialogOpen) {
      if (selectedEvent) {
        setTitle(selectedEvent.title)
        setStartDate(selectedEvent.date)
        setEndDate(selectedEvent.date)
        setStartTime(selectedEvent.startTime)
        setEndTime(selectedEvent.endTime)
        setColor(selectedEvent.color)
        setDescription(selectedEvent.description || "")
        setLocation(selectedEvent.location || "")
        setAllDay(selectedEvent.allDay || false)
        setTimezone(selectedEvent.timezone || "local")
        setRecurrence(selectedEvent.recurrence || "none")
      } else if (selectedDate) {
        // Default values for new event
        setTitle("")
        setStartDate(selectedDate)
        setEndDate(selectedDate)
        setStartTime("09:00")
        setEndTime("10:00")
        setColor("blue")
        setDescription("")
        setLocation("")
        setAllDay(false)
        setTimezone("local")
        setRecurrence("none")
      }
      setActiveTab("details")
    }
  }, [isAddEventDialogOpen, selectedEvent, selectedDate])

  const handleSave = () => {
    if (!startDate) return

    const event: CalendarEvent = {
      id: selectedEvent?.id || Date.now().toString(),
      title,
      date: startDate,
      startTime,
      endTime,
      color,
      description: description || undefined,
      location: location || undefined,
      allDay,
      timezone,
      recurrence,
    }

    saveEvent(event)
    closeAddEventDialog()
  }

  return (
    <Dialog open={isAddEventDialogOpen} onOpenChange={closeAddEventDialog}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{selectedEvent ? "Edit Event" : "Add New Event"}</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="recurrence">Recurrence</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Event Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter event title"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>Start Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !startDate && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {startDate ? format(startDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="grid gap-2">
                <Label>End Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn("w-full justify-start text-left font-normal", !endDate && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {endDate ? format(endDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={endDate} onSelect={setEndDate} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch id="all-day" checked={allDay} onCheckedChange={setAllDay} />
              <Label htmlFor="all-day">All day event</Label>
            </div>

            {!allDay && (
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="start-time">Start Time</Label>
                  <div className="flex">
                    <Input
                      id="start-time"
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="end-time">End Time</Label>
                  <Input id="end-time" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
                </div>
              </div>
            )}

            <div className="grid gap-2">
              <Label htmlFor="location">Location (Optional)</Label>
              <Input
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Enter location"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="color">Event Color</Label>
              <Select value={color} onValueChange={(value) => setColor(value as any)}>
                <SelectTrigger id="color">
                  <SelectValue placeholder="Select color" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yellow">Yellow</SelectItem>
                  <SelectItem value="green">Green</SelectItem>
                  <SelectItem value="purple">Purple</SelectItem>
                  <SelectItem value="red">Red</SelectItem>
                  <SelectItem value="blue">Blue</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter event description"
                rows={3}
              />
            </div>
          </TabsContent>

          <TabsContent value="recurrence" className="py-4">
            <RecurrenceOptions value={recurrence} onChange={setRecurrence} startDate={startDate} />
          </TabsContent>

          <TabsContent value="settings" className="space-y-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="timezone">Timezone</Label>
              <Select value={timezone} onValueChange={setTimezone}>
                <SelectTrigger id="timezone">
                  <SelectValue placeholder="Select timezone" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="local">Local Time</SelectItem>
                  <SelectItem value="utc">UTC</SelectItem>
                  <SelectItem value="america/new_york">Eastern Time (ET)</SelectItem>
                  <SelectItem value="america/chicago">Central Time (CT)</SelectItem>
                  <SelectItem value="america/denver">Mountain Time (MT)</SelectItem>
                  <SelectItem value="america/los_angeles">Pacific Time (PT)</SelectItem>
                  <SelectItem value="europe/london">London (GMT)</SelectItem>
                  <SelectItem value="europe/paris">Paris (CET)</SelectItem>
                  <SelectItem value="asia/tokyo">Tokyo (JST)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={closeAddEventDialog}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!title || !startDate}>
            Save Event
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

