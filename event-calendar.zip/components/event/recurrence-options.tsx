"use client"

import { useState, useEffect } from "react"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Input } from "@/components/ui/input"
import { format } from "date-fns"

interface RecurrenceOptionsProps {
  value: string
  onChange: (value: string) => void
  startDate?: Date
}

export function RecurrenceOptions({ value, onChange, startDate }: RecurrenceOptionsProps) {
  const [frequency, setFrequency] = useState("none")
  const [interval, setInterval] = useState("1")
  const [endType, setEndType] = useState("never")
  const [occurrences, setOccurrences] = useState("10")
  const [endDate, setEndDate] = useState<string>("")

  // Initialize from value
  useEffect(() => {
    if (value === "none") {
      setFrequency("none")
      return
    }

    try {
      const parts = value.split(";")
      const freqPart = parts.find((p) => p.startsWith("FREQ="))
      const intervalPart = parts.find((p) => p.startsWith("INTERVAL="))
      const countPart = parts.find((p) => p.startsWith("COUNT="))
      const untilPart = parts.find((p) => p.startsWith("UNTIL="))

      if (freqPart) {
        setFrequency(freqPart.split("=")[1].toLowerCase())
      }

      if (intervalPart) {
        setInterval(intervalPart.split("=")[1])
      }

      if (countPart) {
        setEndType("count")
        setOccurrences(countPart.split("=")[1])
      } else if (untilPart) {
        setEndType("until")
        setEndDate(untilPart.split("=")[1])
      } else {
        setEndType("never")
      }
    } catch (e) {
      console.error("Error parsing recurrence rule", e)
      setFrequency("none")
    }
  }, [value])

  // Update the recurrence value when options change
  useEffect(() => {
    if (frequency === "none") {
      onChange("none")
      return
    }

    let rule = `FREQ=${frequency.toUpperCase()};INTERVAL=${interval}`

    if (endType === "count") {
      rule += `;COUNT=${occurrences}`
    } else if (endType === "until") {
      rule += `;UNTIL=${endDate}`
    }

    onChange(rule)
  }, [frequency, interval, endType, occurrences, endDate, onChange])

  // Initialize end date if not set
  useEffect(() => {
    if (startDate && !endDate) {
      const defaultEndDate = new Date(startDate)
      defaultEndDate.setMonth(defaultEndDate.getMonth() + 3)
      setEndDate(format(defaultEndDate, "yyyyMMdd"))
    }
  }, [startDate, endDate])

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-base">Repeat</Label>
        <RadioGroup value={frequency} onValueChange={setFrequency} className="mt-2 space-y-2">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="none" id="none" />
            <Label htmlFor="none">Does not repeat</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="daily" id="daily" />
            <Label htmlFor="daily">Daily</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="weekly" id="weekly" />
            <Label htmlFor="weekly">Weekly</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="monthly" id="monthly" />
            <Label htmlFor="monthly">Monthly</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="yearly" id="yearly" />
            <Label htmlFor="yearly">Yearly</Label>
          </div>
        </RadioGroup>
      </div>

      {frequency !== "none" && (
        <>
          <div className="flex items-center space-x-2">
            <Label>Repeat every</Label>
            <Input
              type="number"
              min="1"
              max="99"
              value={interval}
              onChange={(e) => setInterval(e.target.value)}
              className="w-16"
            />
            <span>
              {frequency === "daily"
                ? "days"
                : frequency === "weekly"
                  ? "weeks"
                  : frequency === "monthly"
                    ? "months"
                    : "years"}
            </span>
          </div>

          <div className="space-y-2">
            <Label>Ends</Label>
            <RadioGroup value={endType} onValueChange={setEndType} className="mt-2 space-y-2">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="never" id="never" />
                <Label htmlFor="never">Never</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="count" id="count" />
                <Label htmlFor="count">After</Label>
                <Input
                  type="number"
                  min="1"
                  max="999"
                  value={occurrences}
                  onChange={(e) => setOccurrences(e.target.value)}
                  className="w-16"
                  disabled={endType !== "count"}
                />
                <span>occurrences</span>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="until" id="until" />
                <Label htmlFor="until">On date</Label>
                <Input
                  type="date"
                  value={endDate ? format(new Date(endDate), "yyyy-MM-dd") : ""}
                  onChange={(e) => {
                    const date = new Date(e.target.value)
                    setEndDate(format(date, "yyyyMMdd"))
                  }}
                  className="w-40"
                  disabled={endType !== "until"}
                />
              </div>
            </RadioGroup>
          </div>
        </>
      )}
    </div>
  )
}

