"use client"

import { Button } from "@/components/ui/button"
import { useSettingsStore } from "@/lib/store/settings-store"
import { Moon, Sun } from "lucide-react"

export function ThemeToggle() {
  const { theme, toggleTheme } = useSettingsStore()

  return (
    <Button variant="ghost" size="icon" className="rounded-full" onClick={toggleTheme}>
      {theme === "dark" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}

