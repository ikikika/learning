"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Clock, Filter, Plus, Sun, CalendarIcon } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { CalendarEvent, EventData, ViewType, CalendarViewData, MonthData } from "@/lib/types"
import { EVENTS_DATA } from "@/lib/data"
import { EventDialog } from "./event-dialog"
import { EventDetailsDialog } from "./event-details-dialog"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { DayView } from "./views/day-view"
import { WeekView } from "./views/week-view"
import { MonthView } from "./views/month-view"
import { generateMonthData, getMonthName, getNextMonth, getPrevMonth } from "@/lib/date-utils"

export function FullEventCalendar() {
  // Calendar state
  const [currentDate, setCurrentDate] = useState(new Date(2025, 3, 1)) // April 2025
  const [viewType, setViewType] = useState<ViewType>("month")
  const [events, setEvents] = useState<EventData>(EVENTS_DATA)
  const [monthData, setMonthData] = useState<MonthData>(() =>
    generateMonthData(currentDate.getFullYear(), currentDate.getMonth()),
  )

  // Dialog state
  const [isAddEventDialogOpen, setIsAddEventDialogOpen] = useState(false)
  const [isEventDetailsDialogOpen, setIsEventDetailsDialogOpen] = useState(false)
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null)
  const [is24HourFormat, setIs24HourFormat] = useState(true)

  // Update month data when current date changes
  useEffect(() => {
    setMonthData(generateMonthData(currentDate.getFullYear(), currentDate.getMonth()))
  }, [currentDate])

  // Navigation handlers
  const handlePrevious = () => {
    if (viewType === "day") {
      const newDate = new Date(currentDate)
      newDate.setDate(currentDate.getDate() - 1)
      setCurrentDate(newDate)
    } else if (viewType === "week") {
      const newDate = new Date(currentDate)
      newDate.setDate(currentDate.getDate() - 7)
      setCurrentDate(newDate)
    } else {
      const { year, month } = getPrevMonth(currentDate.getFullYear(), currentDate.getMonth())
      setCurrentDate(new Date(year, month, 1))
    }
  }

  const handleNext = () => {
    if (viewType === "day") {
      const newDate = new Date(currentDate)
      newDate.setDate(currentDate.getDate() + 1)
      setCurrentDate(newDate)
    } else if (viewType === "week") {
      const newDate = new Date(currentDate)
      newDate.setDate(currentDate.getDate() + 7)
      setCurrentDate(newDate)
    } else {
      const { year, month } = getNextMonth(currentDate.getFullYear(), currentDate.getMonth())
      setCurrentDate(new Date(year, month, 1))
    }
  }

  const handleToday = () => {
    setCurrentDate(new Date())
  }

  // Event handlers
  const handleAddEvent = (date: Date) => {
    setSelectedDate(date)
    setIsAddEventDialogOpen(true)
  }

  const handleEventClick = (event: CalendarEvent) => {
    setSelectedEvent(event)
    setIsEventDetailsDialogOpen(true)
  }

  const handleSaveEvent = (event: CalendarEvent) => {
    if (selectedEvent) {
      // Edit existing event
      const updatedEvents = { ...events }
      const dateKey = selectedEvent.date.toISOString().split("T")[0]

      updatedEvents[dateKey] = updatedEvents[dateKey].map((e) =>
        e.id === selectedEvent.id ? { ...event, id: selectedEvent.id } : e,
      )

      setEvents(updatedEvents)
    } else if (selectedDate) {
      // Add new event
      const dateKey = selectedDate.toISOString().split("T")[0]
      const newEvent: CalendarEvent = {
        ...event,
        id: Date.now().toString(),
        date: selectedDate,
      }

      const updatedEvents = { ...events }
      if (!updatedEvents[dateKey]) {
        updatedEvents[dateKey] = []
      }
      updatedEvents[dateKey].push(newEvent)

      setEvents(updatedEvents)
    }
  }

  const handleDeleteEvent = (eventId: string) => {
    if (selectedEvent) {
      const dateKey = selectedEvent.date.toISOString().split("T")[0]
      const updatedEvents = { ...events }

      updatedEvents[dateKey] = updatedEvents[dateKey].filter((e) => e.id !== eventId)

      setEvents(updatedEvents)
      setIsEventDetailsDialogOpen(false)
    }
  }

  // View title based on current view and date
  const getViewTitle = () => {
    if (viewType === "day") {
      return `${currentDate.getDate()} ${getMonthName(currentDate.getMonth())} ${currentDate.getFullYear()}`
    } else if (viewType === "week") {
      const weekStart = new Date(currentDate)
      const day = currentDate.getDay()
      const diff = currentDate.getDate() - day + (day === 0 ? -6 : 1)
      weekStart.setDate(diff)

      const weekEnd = new Date(weekStart)
      weekEnd.setDate(weekStart.getDate() + 6)

      if (weekStart.getMonth() === weekEnd.getMonth()) {
        return `${weekStart.getDate()} - ${weekEnd.getDate()} ${getMonthName(weekStart.getMonth())} ${weekStart.getFullYear()}`
      } else if (weekStart.getFullYear() === weekEnd.getFullYear()) {
        return `${weekStart.getDate()} ${getMonthName(weekStart.getMonth())} - ${weekEnd.getDate()} ${getMonthName(weekEnd.getMonth())} ${weekStart.getFullYear()}`
      } else {
        return `${weekStart.getDate()} ${getMonthName(weekStart.getMonth())} ${weekStart.getFullYear()} - ${weekEnd.getDate()} ${getMonthName(weekEnd.getMonth())} ${weekEnd.getFullYear()}`
      }
    } else {
      return `${getMonthName(currentDate.getMonth())} ${currentDate.getFullYear()}`
    }
  }

  // Prepare view data
  const calendarViewData: CalendarViewData = {
    currentDate,
    events,
    monthData,
    is24HourFormat,
    onEventClick: handleEventClick,
    onAddEvent: handleAddEvent,
  }

  return (
    <>
      <Card className="w-full">
        <CardHeader className="pb-3">
          <CardTitle>Event Calendar</CardTitle>
          <div className="absolute top-4 right-4">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Sun className="h-5 w-5" />
                    <span className="sr-only">Toggle theme</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Toggle theme</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4">
            {/* Calendar Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="icon" onClick={handlePrevious}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <div className="flex items-center space-x-1">
                  <Button variant="outline" onClick={handleToday}>
                    Today
                  </Button>
                  <span className="text-lg font-medium">{getViewTitle()}</span>
                </div>
                <Button variant="ghost" size="icon" onClick={handleNext}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center space-x-2 overflow-x-auto pb-2 md:pb-0">
                <Button variant="outline" size="sm" className="h-8" onClick={() => setIs24HourFormat(!is24HourFormat)}>
                  <Clock className="mr-2 h-4 w-4" />
                  {is24HourFormat ? "24h" : "12h"}
                </Button>
                <Button variant="outline" size="sm" className="h-8">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
                <Button
                  variant={viewType === "month" ? "secondary" : "outline"}
                  size="sm"
                  className="h-8"
                  onClick={() => setViewType("month")}
                >
                  This Month
                </Button>
                <div className="flex border rounded-md">
                  <Button
                    variant={viewType === "day" ? "secondary" : "ghost"}
                    size="sm"
                    className="h-8 px-2 border-r"
                    onClick={() => setViewType("day")}
                  >
                    <CalendarIcon className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewType === "week" ? "secondary" : "ghost"}
                    size="sm"
                    className="h-8 px-2 border-r"
                    onClick={() => setViewType("week")}
                  >
                    <ListViewIcon className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewType === "month" ? "secondary" : "ghost"}
                    size="sm"
                    className="h-8 px-2"
                    onClick={() => setViewType("month")}
                  >
                    <GridViewIcon className="h-4 w-4" />
                  </Button>
                </div>
                <Button
                  className="bg-black text-white hover:bg-gray-800"
                  onClick={() => {
                    setSelectedDate(new Date())
                    setSelectedEvent(null)
                    setIsAddEventDialogOpen(true)
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Event
                </Button>
              </div>
            </div>

            {/* Calendar View */}
            <div className="min-h-[600px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={viewType}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {viewType === "day" && <DayView {...calendarViewData} />}
                  {viewType === "week" && <WeekView {...calendarViewData} />}
                  {viewType === "month" && <MonthView {...calendarViewData} />}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Event Dialogs */}
      <EventDialog
        isOpen={isAddEventDialogOpen}
        onClose={() => setIsAddEventDialogOpen(false)}
        onSave={handleSaveEvent}
        initialDate={selectedDate}
        initialEvent={selectedEvent}
        is24HourFormat={is24HourFormat}
      />

      <EventDetailsDialog
        isOpen={isEventDetailsDialogOpen}
        onClose={() => setIsEventDetailsDialogOpen(false)}
        event={selectedEvent}
        onEdit={() => {
          setIsEventDetailsDialogOpen(false)
          setIsAddEventDialogOpen(true)
        }}
        onDelete={handleDeleteEvent}
        is24HourFormat={is24HourFormat}
      />
    </>
  )
}

function ListViewIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="8" x2="21" y1="6" y2="6" />
      <line x1="8" x2="21" y1="12" y2="12" />
      <line x1="8" x2="21" y1="18" y2="18" />
      <line x1="3" x2="3.01" y1="6" y2="6" />
      <line x1="3" x2="3.01" y1="12" y2="12" />
      <line x1="3" x2="3.01" y1="18" y2="18" />
    </svg>
  )
}

function GridViewIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
      <line x1="3" x2="21" y1="9" y2="9" />
      <line x1="3" x2="21" y1="15" y2="15" />
      <line x1="9" x2="9" y1="3" y2="21" />
      <line x1="15" x2="15" y1="3" y2="21" />
    </svg>
  )
}

