"use client"

import { Button } from "@/components/ui/button"
import { useCalendarStore } from "@/lib/store/calendar-store"
import { useEventStore } from "@/lib/store/event-store"
import { useSettingsStore } from "@/lib/store/settings-store"
import { CalendarIcon, Clock, Download, Filter, Grid, List, Plus, Settings } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function CalendarToolbar() {
  const { viewType, setViewType } = useCalendarStore()
  const { openAddEventDialog, openImportExportDialog, openSettingsDialog } = useEventStore()
  const { is24HourFormat, toggleTimeFormat } = useSettingsStore()

  return (
    <div className="flex items-center space-x-2 overflow-x-auto pb-2 md:pb-0 justify-between">
      <div className="flex items-center space-x-2">
        <Button variant="outline" size="sm" className="h-8" onClick={toggleTimeFormat}>
          <Clock className="mr-2 h-4 w-4" />
          {is24HourFormat ? "24h" : "12h"}
        </Button>
        <Button variant="outline" size="sm" className="h-8">
          <Filter className="mr-2 h-4 w-4" />
          Filter
        </Button>
        <Button
          variant={viewType === "month" ? "secondary" : "outline"}
          size="sm"
          className="h-8"
          onClick={() => setViewType("month")}
        >
          This Month
        </Button>
      </div>

      <div className="flex items-center space-x-2">
        <div className="flex border rounded-md">
          <Button
            variant={viewType === "day" ? "secondary" : "ghost"}
            size="sm"
            className="h-8 px-2 border-r"
            onClick={() => setViewType("day")}
          >
            <CalendarIcon className="h-4 w-4" />
          </Button>
          <Button
            variant={viewType === "week" ? "secondary" : "ghost"}
            size="sm"
            className="h-8 px-2 border-r"
            onClick={() => setViewType("week")}
          >
            <List className="h-4 w-4" />
          </Button>
          <Button
            variant={viewType === "month" ? "secondary" : "ghost"}
            size="sm"
            className="h-8 px-2 border-r"
            onClick={() => setViewType("month")}
          >
            <Grid className="h-4 w-4" />
          </Button>
          <Button
            variant={viewType === "agenda" ? "secondary" : "ghost"}
            size="sm"
            className="h-8 px-2"
            onClick={() => setViewType("agenda")}
          >
            <List className="h-4 w-4 rotate-90" />
          </Button>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="h-8">
              <Settings className="h-4 w-4 mr-2" />
              Options
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={openSettingsDialog}>
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </DropdownMenuItem>
            <DropdownMenuItem onClick={openImportExportDialog}>
              <Download className="h-4 w-4 mr-2" />
              Import/Export
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button className="bg-black text-white hover:bg-gray-800" onClick={openAddEventDialog}>
          <Plus className="mr-2 h-4 w-4" />
          Add Event
        </Button>
      </div>
    </div>
  )
}

