"use client"

import { Button } from "@/components/ui/button"
import { useCalendarStore } from "@/lib/store/calendar-store"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { motion } from "framer-motion"

export function CalendarHeader() {
  const { currentDate, viewType, navigatePrevious, navigateNext, navigateToday, getViewTitle } = useCalendarStore()

  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div className="flex items-center space-x-2">
        <Button variant="ghost" size="icon" onClick={navigatePrevious}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="flex items-center space-x-1">
          <Button variant="outline" onClick={navigateToday}>
            Today
          </Button>
          <motion.span
            key={getViewTitle()}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-lg font-medium px-2"
          >
            {getViewTitle()}
          </motion.span>
        </div>
        <Button variant="ghost" size="icon" onClick={navigateNext}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

