"use client"

import { useCalendarStore } from "@/lib/store/calendar-store"
import { DayView } from "@/components/views/day-view"
import { WeekView } from "@/components/views/week-view"
import { MonthView } from "@/components/views/month-view"
import { AgendaView } from "@/components/views/agenda-view"
import { motion, AnimatePresence } from "framer-motion"

export function CalendarViews() {
  const { viewType, calendarViewData } = useCalendarStore()

  return (
    <div className="min-h-[600px]">
      <AnimatePresence mode="wait">
        <motion.div
          key={viewType}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {viewType === "day" && <DayView {...calendarViewData} />}
          {viewType === "week" && <WeekView {...calendarViewData} />}
          {viewType === "month" && <MonthView {...calendarViewData} />}
          {viewType === "agenda" && <AgendaView {...calendarViewData} />}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

