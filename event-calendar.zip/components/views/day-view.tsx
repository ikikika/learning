"use client"

import { motion } from "framer-motion"
import type { CalendarViewData, CalendarEvent } from "@/lib/types"
import { cn } from "@/lib/utils"
import { formatDateKey, generateTimeSlots } from "@/lib/date-utils"
import { useSettingsStore } from "@/lib/store/settings-store"
import { useDraggable } from "@/lib/hooks/use-draggable"

export function DayView({ currentDate, events, onEventClick, onAddEvent }: CalendarViewData) {
  const { is24HourFormat } = useSettingsStore()
  const timeSlots = generateTimeSlots(is24HourFormat, 30) // 30-minute intervals
  const { handleDragStart, handleDragOver, handleDrop } = useDraggable()

  const getEventsForDay = (date: Date): CalendarEvent[] => {
    const dateKey = formatDateKey(date)
    return events[dateKey] || []
  }

  const dayEvents = getEventsForDay(currentDate)
  const allDayEvents = dayEvents.filter((e) => e.allDay)
  const timedEvents = dayEvents.filter((e) => !e.allDay)
  const dateKey = formatDateKey(currentDate)

  const getEventPosition = (event: CalendarEvent): { top: number; height: number } => {
    const startHour = Number.parseInt(event.startTime.split(":")[0])
    const startMinute = Number.parseInt(event.startTime.split(":")[1])
    const endHour = Number.parseInt(event.endTime.split(":")[0])
    const endMinute = Number.parseInt(event.endTime.split(":")[1])

    const startInMinutes = startHour * 60 + startMinute
    const endInMinutes = endHour * 60 + endMinute
    const durationInMinutes = endInMinutes - startInMinutes

    // Each hour is 120px tall (30 min = 60px)
    const top = (startInMinutes / 30) * 30
    const height = (durationInMinutes / 30) * 30

    return { top, height }
  }

  const getEventTimeDisplay = (event: CalendarEvent): string => {
    if (event.allDay) return "All day"

    const startHour = Number.parseInt(event.startTime.split(":")[0])
    const startMinute = Number.parseInt(event.startTime.split(":")[1])
    const endHour = Number.parseInt(event.endTime.split(":")[0])
    const endMinute = Number.parseInt(event.endTime.split(":")[1])

    let startDisplay = ""
    let endDisplay = ""

    if (is24HourFormat) {
      startDisplay = `${startHour.toString().padStart(2, "0")}:${startMinute.toString().padStart(2, "0")}`
      endDisplay = `${endHour.toString().padStart(2, "0")}:${endMinute.toString().padStart(2, "0")}`
    } else {
      const startPeriod = startHour >= 12 ? "PM" : "AM"
      const endPeriod = endHour >= 12 ? "PM" : "AM"
      const displayStartHour = startHour % 12 || 12
      const displayEndHour = endHour % 12 || 12

      startDisplay = `${displayStartHour}:${startMinute.toString().padStart(2, "0")} ${startPeriod}`
      endDisplay = `${displayEndHour}:${endMinute.toString().padStart(2, "0")} ${endPeriod}`
    }

    return `${startDisplay} - ${endDisplay}`
  }

  return (
    <div className="flex flex-col">
      {/* All-day events */}
      {allDayEvents.length > 0 && (
        <div className="grid grid-cols-[100px_1fr] border-b mb-2">
          <div className="p-2 border-r text-sm font-medium">All day</div>
          <div
            className="p-1 min-h-[60px]"
            onDragOver={(e) => handleDragOver(e)}
            onDrop={(e) => handleDrop(e, currentDate, true)}
            data-date={dateKey}
            data-all-day="true"
          >
            {allDayEvents.map((event) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn(
                  "text-xs p-1 mb-1 rounded cursor-pointer",
                  event.color === "yellow" && "bg-yellow-100 dark:bg-yellow-900",
                  event.color === "green" && "bg-green-100 dark:bg-green-900",
                  event.color === "purple" && "bg-purple-100 dark:bg-purple-900",
                  event.color === "red" && "bg-red-100 dark:bg-red-900",
                  event.color === "blue" && "bg-blue-100 dark:bg-blue-900",
                )}
                onClick={() => onEventClick(event)}
                draggable
                onDragStart={(e) => handleDragStart(e, event)}
              >
                <div className="font-medium">{event.title}</div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Time grid */}
      <div className="grid grid-cols-[100px_1fr] relative">
        {/* Time labels */}
        <div className="border-r">
          {timeSlots.map((slot, index) => (
            <div key={index} className="h-[30px] border-b text-xs text-right pr-2 -mt-3">
              {index % 2 === 0 && <span className="bg-white dark:bg-gray-950 px-1">{slot.label}</span>}
            </div>
          ))}
        </div>

        {/* Events column */}
        <div
          className="relative"
          onClick={() => onAddEvent(currentDate)}
          onDragOver={(e) => handleDragOver(e)}
          onDrop={(e) => handleDrop(e, currentDate)}
          data-date={dateKey}
        >
          {/* Time grid background */}
          {timeSlots.map((slot, index) => (
            <div
              key={index}
              className={cn(
                "h-[30px] border-b",
                index % 2 === 0 && "border-b-gray-300 dark:border-b-gray-700",
                index % 2 !== 0 && "border-b-gray-100 dark:border-b-gray-800",
              )}
            />
          ))}

          {/* Current time indicator */}
          <div
            className="absolute left-0 right-0 border-t-2 border-red-500 z-10"
            style={{
              top: `${((new Date().getHours() * 60 + new Date().getMinutes()) / 30) * 30}px`,
            }}
          >
            <div className="w-2 h-2 rounded-full bg-red-500 -mt-1 -ml-1"></div>
          </div>

          {/* Events */}
          {timedEvents.map((event) => {
            const { top, height } = getEventPosition(event)

            return (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, x: -5 }}
                animate={{ opacity: 1, x: 0 }}
                className={cn(
                  "absolute left-1 right-1 text-xs p-2 rounded cursor-pointer",
                  event.color === "yellow" && "bg-yellow-100 dark:bg-yellow-900",
                  event.color === "green" && "bg-green-100 dark:bg-green-900",
                  event.color === "purple" && "bg-purple-100 dark:bg-purple-900",
                  event.color === "red" && "bg-red-100 dark:bg-red-900",
                  event.color === "blue" && "bg-blue-100 dark:bg-blue-900",
                )}
                style={{
                  top: `${top}px`,
                  height: `${Math.max(height, 25)}px`,
                }}
                onClick={(e) => {
                  e.stopPropagation()
                  onEventClick(event)
                }}
                draggable
                onDragStart={(e) => handleDragStart(e, event)}
              >
                <div className="font-medium">{event.title}</div>
                <div>{getEventTimeDisplay(event)}</div>
                {height > 60 && event.location && (
                  <div className="mt-1 text-muted-foreground truncate">{event.location}</div>
                )}
              </motion.div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

