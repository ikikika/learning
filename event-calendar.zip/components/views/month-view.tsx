"use client"

import { motion, AnimatePresence } from "framer-motion"
import type { CalendarViewData, CalendarEvent } from "@/lib/types"
import { cn } from "@/lib/utils"
import { formatDateKey, getShortDayName } from "@/lib/date-utils"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { useState } from "react"
import { useSettingsStore } from "@/lib/store/settings-store"
import { useDraggable } from "@/lib/hooks/use-draggable"

export function MonthView({ currentDate, events, monthData, onEventClick, onAddEvent }: CalendarViewData) {
  const [openPopoverDay, setOpenPopoverDay] = useState<string | null>(null)
  const { is24HourFormat } = useSettingsStore()
  const { handleDragStart, handleDragOver, handleDrop } = useDraggable()

  const getEventsForDay = (date: Date): CalendarEvent[] => {
    const dateKey = formatDateKey(date)
    return events[dateKey] || []
  }

  const getEventTimeDisplay = (event: CalendarEvent): string => {
    if (event.allDay) return ""

    const startHour = Number.parseInt(event.startTime.split(":")[0])
    const startMinute = Number.parseInt(event.startTime.split(":")[1])
    const endHour = Number.parseInt(event.endTime.split(":")[0])
    const endMinute = Number.parseInt(event.endTime.split(":")[1])

    let startDisplay = ""
    let endDisplay = ""

    if (is24HourFormat) {
      startDisplay = `${startHour.toString().padStart(2, "0")}:${startMinute.toString().padStart(2, "0")}`
      endDisplay = `${endHour.toString().padStart(2, "0")}:${endMinute.toString().padStart(2, "0")}`
    } else {
      const startPeriod = startHour >= 12 ? "PM" : "AM"
      const endPeriod = endHour >= 12 ? "PM" : "AM"
      const displayStartHour = startHour % 12 || 12
      const displayEndHour = endHour % 12 || 12

      startDisplay = `${displayStartHour}:${startMinute.toString().padStart(2, "0")} ${startPeriod}`
      endDisplay = `${displayEndHour}:${endMinute.toString().padStart(2, "0")} ${endPeriod}`
    }

    return `${startDisplay} - ${endDisplay}`
  }

  return (
    <div className="grid grid-cols-7 gap-1">
      {/* Day headers */}
      {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
        <div key={day} className="text-center py-2 font-medium">
          {day}
        </div>
      ))}

      {/* Calendar days */}
      {monthData.weeks.flatMap((week) =>
        week.days.map((day, dayIndex) => {
          const dayEvents = getEventsForDay(day.date)
          const dateKey = formatDateKey(day.date)

          return (
            <div
              key={dateKey}
              className={cn(
                "border min-h-[120px] p-1 relative",
                !day.isCurrentMonth && "opacity-50 bg-gray-50 dark:bg-gray-900",
                day.isToday && "border-primary",
              )}
              onClick={() => onAddEvent(day.date)}
              onDragOver={(e) => handleDragOver(e)}
              onDrop={(e) => handleDrop(e, day.date)}
              data-date={dateKey}
            >
              <div
                className={cn(
                  "absolute top-1 left-2 font-medium",
                  day.isToday &&
                    "bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center -ml-1",
                )}
              >
                {day.date.getDate()}
              </div>

              <div className="mt-6 space-y-1">
                <AnimatePresence>
                  {dayEvents.slice(0, 2).map((event, idx) => (
                    <motion.div
                      key={event.id}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, height: 0 }}
                      className={cn(
                        "text-xs p-1 rounded cursor-pointer",
                        event.color === "yellow" && "bg-yellow-100 dark:bg-yellow-900",
                        event.color === "green" && "bg-green-100 dark:bg-green-900",
                        event.color === "purple" && "bg-purple-100 dark:bg-purple-900",
                        event.color === "red" && "bg-red-100 dark:bg-red-900",
                        event.color === "blue" && "bg-blue-100 dark:bg-blue-900",
                      )}
                      onClick={(e) => {
                        e.stopPropagation()
                        onEventClick(event)
                      }}
                      draggable
                      onDragStart={(e) => handleDragStart(e, event)}
                    >
                      <div className="font-medium">{event.title}</div>
                      {!event.allDay && <div>{getEventTimeDisplay(event)}</div>}
                    </motion.div>
                  ))}
                </AnimatePresence>

                {dayEvents.length > 2 && (
                  <Popover
                    open={openPopoverDay === dateKey}
                    onOpenChange={(open) => {
                      if (open) {
                        setOpenPopoverDay(dateKey)
                      } else {
                        setOpenPopoverDay(null)
                      }
                    }}
                  >
                    <PopoverTrigger asChild>
                      <div
                        className="text-xs text-center text-muted-foreground cursor-pointer hover:bg-muted/50 rounded py-0.5"
                        onClick={(e) => {
                          e.stopPropagation()
                        }}
                      >
                        +{dayEvents.length - 2} more
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-64 p-0" align="start">
                      <div className="p-2 border-b">
                        <div className="font-medium">
                          {day.date.getDate()} {getShortDayName(day.date.getDay())}
                        </div>
                      </div>
                      <div className="max-h-[300px] overflow-y-auto p-1">
                        {dayEvents.map((event) => (
                          <div
                            key={event.id}
                            className={cn(
                              "text-xs p-2 rounded my-1 cursor-pointer",
                              event.color === "yellow" && "bg-yellow-100 dark:bg-yellow-900",
                              event.color === "green" && "bg-green-100 dark:bg-green-900",
                              event.color === "purple" && "bg-purple-100 dark:bg-purple-900",
                              event.color === "red" && "bg-red-100 dark:bg-red-900",
                              event.color === "blue" && "bg-blue-100 dark:bg-blue-900",
                            )}
                            onClick={(e) => {
                              e.stopPropagation()
                              setOpenPopoverDay(null)
                              onEventClick(event)
                            }}
                          >
                            <div className="font-medium">{event.title}</div>
                            {!event.allDay && <div>{getEventTimeDisplay(event)}</div>}
                          </div>
                        ))}
                      </div>
                    </PopoverContent>
                  </Popover>
                )}
              </div>
            </div>
          )
        }),
      )}
    </div>
  )
}

