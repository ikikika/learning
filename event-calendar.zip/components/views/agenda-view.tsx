"use client"

import { motion } from "framer-motion"
import type { CalendarViewData, CalendarEvent } from "@/lib/types"
import { cn } from "@/lib/utils"
import { getMonthName, getShortDayName } from "@/lib/date-utils"
import { useSettingsStore } from "@/lib/store/settings-store"
import { useDraggable } from "@/lib/hooks/use-draggable"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronRight } from "lucide-react"
import { useState } from "react"

export function AgendaView({ currentDate, events, onEventClick }: CalendarViewData) {
  const { is24HourFormat } = useSettingsStore()
  const { handleDragStart } = useDraggable()
  const [expandedDates, setExpandedDates] = useState<Record<string, boolean>>({})

  // Get all events and group by date
  const eventsByDate: Record<string, { date: Date; events: CalendarEvent[] }> = {}

  Object.entries(events).forEach(([dateKey, dateEvents]) => {
    if (dateEvents.length > 0) {
      const date = new Date(dateKey)
      eventsByDate[dateKey] = {
        date,
        events: dateEvents,
      }
    }
  })

  // Sort dates
  const sortedDates = Object.keys(eventsByDate).sort()

  const getEventTimeDisplay = (event: CalendarEvent): string => {
    if (event.allDay) return "All day"

    const startHour = Number.parseInt(event.startTime.split(":")[0])
    const startMinute = Number.parseInt(event.startTime.split(":")[1])
    const endHour = Number.parseInt(event.endTime.split(":")[0])
    const endMinute = Number.parseInt(event.endTime.split(":")[1])

    let startDisplay = ""
    let endDisplay = ""

    if (is24HourFormat) {
      startDisplay = `${startHour.toString().padStart(2, "0")}:${startMinute.toString().padStart(2, "0")}`
      endDisplay = `${endHour.toString().padStart(2, "0")}:${endMinute.toString().padStart(2, "0")}`
    } else {
      const startPeriod = startHour >= 12 ? "PM" : "AM"
      const endPeriod = endHour >= 12 ? "PM" : "AM"
      const displayStartHour = startHour % 12 || 12
      const displayEndHour = endHour % 12 || 12

      startDisplay = `${displayStartHour}:${startMinute.toString().padStart(2, "0")} ${startPeriod}`
      endDisplay = `${displayEndHour}:${endMinute.toString().padStart(2, "0")} ${endPeriod}`
    }

    return `${startDisplay} - ${endDisplay}`
  }

  const toggleDateExpanded = (dateKey: string) => {
    setExpandedDates((prev) => ({
      ...prev,
      [dateKey]: !prev[dateKey],
    }))
  }

  return (
    <div className="flex flex-col space-y-2">
      {sortedDates.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">No events to display</div>
      ) : (
        sortedDates.map((dateKey) => {
          const { date, events: dateEvents } = eventsByDate[dateKey]
          const isToday = new Date().toDateString() === date.toDateString()
          const isExpanded = expandedDates[dateKey] !== false // Default to expanded

          return (
            <div key={dateKey} className="border rounded-md overflow-hidden">
              <div
                className={cn(
                  "flex items-center justify-between p-3 cursor-pointer",
                  isToday ? "bg-blue-50 dark:bg-blue-900/20" : "bg-gray-50 dark:bg-gray-900",
                )}
                onClick={() => toggleDateExpanded(dateKey)}
              >
                <div className="flex items-center">
                  <Button variant="ghost" size="icon" className="h-6 w-6 mr-2">
                    {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  </Button>
                  <div>
                    <span className="font-medium">{getShortDayName(date.getDay())}, </span>
                    <span>
                      {date.getDate()} {getMonthName(date.getMonth())} {date.getFullYear()}
                    </span>
                  </div>
                </div>
                <div className="text-sm text-muted-foreground">
                  {dateEvents.length} event{dateEvents.length !== 1 ? "s" : ""}
                </div>
              </div>

              {isExpanded && (
                <div className="divide-y">
                  {dateEvents.map((event) => (
                    <motion.div
                      key={event.id}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="p-3 hover:bg-gray-50 dark:hover:bg-gray-900 cursor-pointer"
                      onClick={() => onEventClick(event)}
                      draggable
                      onDragStart={(e) => handleDragStart(e, event)}
                    >
                      <div className="flex items-start">
                        <div
                          className={cn(
                            "w-3 h-3 rounded-full mt-1 mr-3",
                            event.color === "yellow" && "bg-yellow-400",
                            event.color === "green" && "bg-green-400",
                            event.color === "purple" && "bg-purple-400",
                            event.color === "red" && "bg-red-400",
                            event.color === "blue" && "bg-blue-400",
                          )}
                        />
                        <div className="flex-1">
                          <div className="font-medium">{event.title}</div>
                          <div className="text-sm text-muted-foreground">{getEventTimeDisplay(event)}</div>
                          {event.location && <div className="text-sm text-muted-foreground mt-1">{event.location}</div>}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )
        })
      )}
    </div>
  )
}

