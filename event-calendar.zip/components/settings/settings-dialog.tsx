"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { useEventStore } from "@/lib/store/event-store"
import { useSettingsStore } from "@/lib/store/settings-store"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { useState } from "react"

export function SettingsDialog() {
  const { isSettingsDialogOpen, closeSettingsDialog } = useEventStore()
  const {
    is24HourFormat,
    toggleTimeFormat,
    theme,
    setTheme,
    primaryColor,
    setPrimaryColor,
    weekStartsOn,
    setWeekStartsOn,
    defaultView,
    setDefaultView,
    defaultDuration,
    setDefaultDuration,
  } = useSettingsStore()

  const [activeTab, setActiveTab] = useState("general")

  return (
    <Dialog open={isSettingsDialogOpen} onOpenChange={closeSettingsDialog}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Calendar Settings</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="events">Events</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-4 py-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="24h-format">Use 24-hour format</Label>
              <Switch id="24h-format" checked={is24HourFormat} onCheckedChange={toggleTimeFormat} />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="week-starts">Week starts on</Label>
              <Select value={weekStartsOn} onValueChange={setWeekStartsOn}>
                <SelectTrigger id="week-starts">
                  <SelectValue placeholder="Select day" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monday">Monday</SelectItem>
                  <SelectItem value="sunday">Sunday</SelectItem>
                  <SelectItem value="saturday">Saturday</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="default-view">Default calendar view</Label>
              <Select value={defaultView} onValueChange={setDefaultView}>
                <SelectTrigger id="default-view">
                  <SelectValue placeholder="Select view" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="day">Day</SelectItem>
                  <SelectItem value="week">Week</SelectItem>
                  <SelectItem value="month">Month</SelectItem>
                  <SelectItem value="agenda">Agenda</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="appearance" className="space-y-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="theme">Theme</Label>
              <Select value={theme} onValueChange={setTheme}>
                <SelectTrigger id="theme">
                  <SelectValue placeholder="Select theme" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Light</SelectItem>
                  <SelectItem value="dark">Dark</SelectItem>
                  <SelectItem value="system">System</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="primary-color">Primary Color</Label>
              <Select value={primaryColor} onValueChange={setPrimaryColor}>
                <SelectTrigger id="primary-color">
                  <SelectValue placeholder="Select color" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="blue">Blue</SelectItem>
                  <SelectItem value="green">Green</SelectItem>
                  <SelectItem value="purple">Purple</SelectItem>
                  <SelectItem value="red">Red</SelectItem>
                  <SelectItem value="orange">Orange</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="events" className="space-y-4 py-4">
            <div className="grid gap-2">
              <Label>Default event duration (minutes)</Label>
              <div className="flex items-center space-x-4">
                <Slider
                  value={[defaultDuration]}
                  min={15}
                  max={120}
                  step={15}
                  onValueChange={(value) => setDefaultDuration(value[0])}
                  className="flex-1"
                />
                <span className="w-12 text-center">{defaultDuration}</span>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={closeSettingsDialog}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

