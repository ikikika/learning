"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useEventStore } from "@/lib/store/event-store"
import { useState } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Download, Upload } from "lucide-react"
import { exportToICalendar, exportToJSON, importFromICalendar, importFromJSON } from "@/lib/import-export"

export function ImportExportDialog() {
  const { isImportExportDialogOpen, closeImportExportDialog, events, importEvents } = useEventStore()

  const [activeTab, setActiveTab] = useState("export")
  const [importData, setImportData] = useState("")
  const [importFormat, setImportFormat] = useState<"json" | "ical">("json")
  const [exportFormat, setExportFormat] = useState<"json" | "ical">("json")
  const [importError, setImportError] = useState<string | null>(null)
  const [importSuccess, setImportSuccess] = useState<string | null>(null)

  const handleExport = () => {
    try {
      let exportData = ""
      let filename = ""
      let mimeType = ""

      if (exportFormat === "json") {
        exportData = exportToJSON(events)
        filename = "calendar-events.json"
        mimeType = "application/json"
      } else {
        exportData = exportToICalendar(events)
        filename = "calendar-events.ics"
        mimeType = "text/calendar"
      }

      // Create download link
      const blob = new Blob([exportData], { type: mimeType })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()

      // Clean up
      setTimeout(() => {
        document.body.removeChild(a)
        URL.revokeObjectURL(url)
      }, 0)
    } catch (error) {
      console.error("Export error:", error)
    }
  }

  const handleImport = () => {
    setImportError(null)
    setImportSuccess(null)

    try {
      let importedEvents

      if (importFormat === "json") {
        importedEvents = importFromJSON(importData)
      } else {
        importedEvents = importFromICalendar(importData)
      }

      if (importedEvents && Object.keys(importedEvents).length > 0) {
        importEvents(importedEvents)
        setImportSuccess(`Successfully imported ${Object.values(importedEvents).flat().length} events`)
        setImportData("")
      } else {
        setImportError("No valid events found in the import data")
      }
    } catch (error) {
      console.error("Import error:", error)
      setImportError(`Import failed: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  return (
    <Dialog open={isImportExportDialogOpen} onOpenChange={closeImportExportDialog}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Import/Export Calendar Data</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="export">Export</TabsTrigger>
            <TabsTrigger value="import">Import</TabsTrigger>
          </TabsList>

          <TabsContent value="export" className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Export Format</Label>
              <div className="flex space-x-2">
                <Button
                  variant={exportFormat === "json" ? "default" : "outline"}
                  onClick={() => setExportFormat("json")}
                >
                  JSON
                </Button>
                <Button
                  variant={exportFormat === "ical" ? "default" : "outline"}
                  onClick={() => setExportFormat("ical")}
                >
                  iCalendar
                </Button>
              </div>
            </div>

            <div className="pt-4">
              <Button onClick={handleExport} className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Export Calendar Data
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="import" className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Import Format</Label>
              <div className="flex space-x-2">
                <Button
                  variant={importFormat === "json" ? "default" : "outline"}
                  onClick={() => setImportFormat("json")}
                >
                  JSON
                </Button>
                <Button
                  variant={importFormat === "ical" ? "default" : "outline"}
                  onClick={() => setImportFormat("ical")}
                >
                  iCalendar
                </Button>
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="import-data">Paste {importFormat === "json" ? "JSON" : "iCalendar"} Data</Label>
              <Textarea
                id="import-data"
                value={importData}
                onChange={(e) => setImportData(e.target.value)}
                placeholder={`Paste your ${importFormat === "json" ? "JSON" : "iCalendar"} data here...`}
                rows={10}
              />
            </div>

            {importError && (
              <Alert variant="destructive">
                <AlertDescription>{importError}</AlertDescription>
              </Alert>
            )}

            {importSuccess && (
              <Alert>
                <AlertDescription>{importSuccess}</AlertDescription>
              </Alert>
            )}

            <div className="pt-2">
              <Button onClick={handleImport} className="w-full" disabled={!importData.trim()}>
                <Upload className="mr-2 h-4 w-4" />
                Import Calendar Data
              </Button>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={closeImportExportDialog}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

