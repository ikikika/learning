"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import type { CalendarEvent } from "@/lib/types"

interface EventDialogProps {
  isOpen: boolean
  onClose: () => void
  onSave: (event: CalendarEvent) => void
  initialDate: Date | null
  initialEvent: CalendarEvent | null
  is24HourFormat: boolean
}

export function EventDialog({ isOpen, onClose, onSave, initialDate, initialEvent, is24HourFormat }: EventDialogProps) {
  const [title, setTitle] = useState("")
  const [startTime, setStartTime] = useState("09:00")
  const [endTime, setEndTime] = useState("10:00")
  const [color, setColor] = useState<"yellow" | "green" | "purple" | "red" | "blue">("blue")
  const [description, setDescription] = useState("")
  const [location, setLocation] = useState("")
  const [allDay, setAllDay] = useState(false)

  // Reset form when dialog opens with new data
  useEffect(() => {
    if (isOpen) {
      if (initialEvent) {
        setTitle(initialEvent.title)
        setStartTime(initialEvent.startTime)
        setEndTime(initialEvent.endTime)
        setColor(initialEvent.color)
        setDescription(initialEvent.description || "")
        setLocation(initialEvent.location || "")
        setAllDay(initialEvent.allDay || false)
      } else {
        // Default values for new event
        setTitle("")
        setStartTime("09:00")
        setEndTime("10:00")
        setColor("blue")
        setDescription("")
        setLocation("")
        setAllDay(false)
      }
    }
  }, [isOpen, initialEvent])

  const handleSave = () => {
    if (!initialDate && !initialEvent) return

    const eventDate = initialEvent ? initialEvent.date : initialDate!

    const event: CalendarEvent = {
      id: initialEvent?.id || Date.now().toString(),
      title,
      date: eventDate,
      startTime,
      endTime,
      color,
      description: description || undefined,
      location: location || undefined,
      allDay,
    }

    onSave(event)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{initialEvent ? "Edit Event" : "Add New Event"}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="title">Event Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter event title"
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch id="all-day" checked={allDay} onCheckedChange={setAllDay} />
            <Label htmlFor="all-day">All day event</Label>
          </div>

          {!allDay && (
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="start-time">Start Time</Label>
                <Input id="start-time" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="end-time">End Time</Label>
                <Input id="end-time" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
              </div>
            </div>
          )}

          <div className="grid gap-2">
            <Label htmlFor="location">Location (Optional)</Label>
            <Input
              id="location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Enter location"
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="color">Event Color</Label>
            <Select value={color} onValueChange={(value) => setColor(value as any)}>
              <SelectTrigger id="color">
                <SelectValue placeholder="Select color" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="yellow">Yellow</SelectItem>
                <SelectItem value="green">Green</SelectItem>
                <SelectItem value="purple">Purple</SelectItem>
                <SelectItem value="red">Red</SelectItem>
                <SelectItem value="blue">Blue</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter event description"
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Event</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

