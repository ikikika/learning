"use client"

import { useEffect } from "react"
import { CalendarHeader } from "@/components/calendar/calendar-header"
import { CalendarToolbar } from "@/components/calendar/calendar-toolbar"
import { CalendarViews } from "@/components/calendar/calendar-views"
import { EventDialog } from "@/components/event/event-dialog"
import { EventDetailsDialog } from "@/components/event/event-details-dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useCalendarStore } from "@/lib/store/calendar-store"
import { useEventStore } from "@/lib/store/event-store"
import { useSettingsStore } from "@/lib/store/settings-store"
import { ImportExportDialog } from "@/components/settings/import-export-dialog"
import { SettingsDialog } from "@/components/settings/settings-dialog"
import { ThemeToggle } from "@/components/theme-toggle"

export function CalendarApp() {
  const { currentDate, viewType, setMonthData, generateMonthData } = useCalendarStore()

  const { isAddEventDialogOpen, isEventDetailsDialogOpen, isImportExportDialogOpen, isSettingsDialogOpen } =
    useEventStore()

  const { theme, toggleTheme } = useSettingsStore()

  // Update month data when current date changes
  useEffect(() => {
    setMonthData(generateMonthData(currentDate.getFullYear(), currentDate.getMonth()))
  }, [currentDate, setMonthData, generateMonthData])

  return (
    <>
      <Card className="w-full">
        <CardHeader className="pb-3">
          <CardTitle>Event Calendar</CardTitle>
          <div className="absolute top-4 right-4">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <ThemeToggle />
                </TooltipTrigger>
                <TooltipContent>
                  <p>Toggle theme</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4">
            {/* Calendar Header */}
            <CalendarHeader />

            {/* Calendar Toolbar */}
            <CalendarToolbar />

            {/* Calendar Views */}
            <CalendarViews />
          </div>
        </CardContent>
      </Card>

      {/* Dialogs */}
      <EventDialog />
      <EventDetailsDialog />
      <ImportExportDialog />
      <SettingsDialog />
    </>
  )
}

