import { CalendarApp } from "@/components/calendar-app"

export default function Home() {
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Full Event Calendar Demo</h1>
          <p className="text-muted-foreground">A modern, accessible, and customizable calendar component</p>
        </div>
        <button className="bg-black text-white px-4 py-2 rounded-md mt-4 md:mt-0 hover:bg-gray-800">
          Get your calendar today
        </button>
      </div>
      <CalendarApp />
    </div>
  )
}

