# Review instructions

This is the policy that every reviewer of this repository, human or agent, applies to every change.

> **Edit this file.** It ships with sensible generic defaults. The three things to change first are
> the *Do not report* list, the definition of *Important*, and the limit on minor comments. A review
> policy nobody has edited is one nobody has agreed to.

## Passes

Run three passes and **tag every finding with the pass that produced it**. Do not merge the passes.
The tags are what let a reader sort the findings in ten seconds instead of ten minutes.

- **Bugs**: logic errors, unhandled edge cases, subtle regressions, concurrency problems, error
  paths that swallow failures, resource leaks.
- **Security**: injection, gaps in authentication and authorisation, secrets in code or logs,
  personal data in log lines and error messages, unsafe deserialisation, dependency risk.
- **Compliance**: does the change match `spec.md` and `plan.md`? Does it keep the rules stated in
  `CLAUDE.md`? Did it touch files the plan never mentioned?

## What *Important* means here

Reserve **Important** for findings that would **break behaviour, leak data, or breach a stated
policy**. Style, naming and personal preference are minor comments, called nits.

Applying this honestly is most of the job. If everything is marked Important, nothing is, and the
team stops reading the reviews within two weeks.

An Important finding must be **concrete**: the input or state that triggers it, and the wrong output
or crash it produces. If you cannot make it concrete, it is a suspicion. Say so, or leave it out.

## Limit the nits

Report at most **five** nits per review, then give a count of the rest.

A review with no limit is not read, and a review that is not read is worse than no review, because
it uses up the team's willingness to have one.

## Do not report

- Anything CI already enforces: formatting, lint, import order, type errors. It is noise, and the
  reader learns to skim your reviews.
- Generated files, vendored dependencies, lock files.
- Test fixtures and golden files, unless the assertion itself is wrong.
- Preferences with no defensible reason. "I would have written this differently" is not a finding.

<!-- Add your repo's paths here, e.g.:
- Generated code under `src/gen/`
- Anything under `vendor/`
-->

## How to report a finding

- File and line.
- The pass, and whether it is Important or a nit.
- What is wrong. For an Important finding, the concrete failure.
- The suggested fix, briefly.

**Say when you found nothing.** "No Important findings; three nits" is a complete review. Inventing
a finding to look thorough is the fastest way to make this review worthless.

## Who decides

Findings do not approve or block a change on their own. A named person approves. See the profile in
`docs/05-profiles.md`. The agent that wrote the change is never that person.

## Feeding findings back

When a review finds a mistake this repository has now seen **twice**, add the correction to
`CLAUDE.md`. Once is noise. Twice is a pattern, and a pattern belongs in the file every session
reads.

Rate the reviewer's findings monthly. If the ratio of useful findings to noise is falling, tighten
the *Do not report* list before you change anything else. Over-reporting is almost always the cause.
