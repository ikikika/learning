# Enterprise controls

`managed-settings.json` is the configuration for regulated environments. **The installer will not
install it**, and that is deliberate. Anything an engineer can edit does not control that engineer.
IT or the platform team deploys this file through device management software to the managed settings
path. That path is outside the repository and outside the user's home configuration, and no project
file or command-line flag can override it.

Treat the shipped file as a starting point. Every value in it is an organisational decision.

## What each setting does

| Setting | What it prevents |
|---|---|
| `permissions.deny` | Secrets being read. Arbitrary outbound network access through `curl`, `wget` or `WebFetch` |
| `permissions.allow` | People ignoring permission prompts. Pre-approving the safe everyday commands is what keeps the deny list credible |
| `disableBypassPermissionsMode` | The one flag that would turn everything above into guidance |
| `allowManagedPermissionRulesOnly` | A project `settings.json` or a command-line flag widening the rules locally |
| `sandbox.failIfUnavailable` | Silently running without isolation when the sandbox cannot start |
| `sandbox.network.allowedDomains` | Outbound access to any domain not on the list, enforced by the operating system rather than by asking |
| `credentials` | Secrets being read, and being inherited by processes started inside the sandbox |
| `allowManagedHooksOnly` | A local hook replacing or bypassing your approval gates |
| `disableSideloadFlags` and `strictKnownMarketplaces` | Skills, agents and MCP servers arriving from anywhere other than an approved marketplace |
| `allowManagedMcpServersOnly` | The set of available tools growing by discovery rather than by decision |
| `requiredMinimumVersion` | Sessions running on a client version you have not reviewed |

## Getting the balance right

There are two ways to get this wrong, and the second is the one people usually walk into.

**Too loose** is obvious, and an audit will catch it.

**Too tight** is not obvious. An engineer who is prompted for every command stops reading the
prompts, and a control that everyone clicks through has become a delay rather than a control. The
`allow` list is not a convenience. It is what keeps the `deny` list meaningful. Pre-approve the
everyday commands generously, and apply strictness to outbound network access, credentials, and the
set of available tools.

## Rolling it out

1. **Start in a reporting mode where you can.** Run with the deny list and the sandbox, but without
   `allowManagedPermissionRulesOnly`, for two weeks. Record what people actually run into.
2. **Widen the `allow` list from that evidence**, not from guesswork.
3. **Then lock it.** Turn on `allowManagedPermissionRulesOnly`, `allowManagedHooksOnly` and
   `disableSideloadFlags` together. Each is weak without the others.
4. **Pin `requiredMinimumVersion`** and give a named person responsibility for updating it. A
   version pin with no owner becomes a blocker within a quarter.

## Model access

If network policy or data residency rules prevent calling the Anthropic API directly, the same setup
runs against AWS Bedrock, Google Vertex AI, or Microsoft Foundry. That is a deployment decision that
changes nothing else in this kit. The skills, hooks, artifacts and evals are identical.
