# The artifact chain

Every stage of the process produces a file, called an artifact, that is committed to git and read by
the next stage. Together, the artifacts are the audit trail. There is no separate compliance
document, because doing the work produces the record.

## Layout

One directory per change, named with a short hyphenated name (a "slug"):

```
sdlc/
├── templates/                          # copy these; do not edit them in place
│   ├── intent.md · spec.md · plan.md · postmortem.md
└── claims-status-self-service/
    ├── intent.md        # Stage 1: why. Written by the originator, accepted by the product owner
    ├── spec.md          # Stage 2: what. Requirements and design, checked against policy, conflicts recorded
    ├── plan.md          # Stage 3: how. Reviewed before any code exists
    ├── review.md        # Stage 5: findings (trunk-local profile; pull request threads otherwise)
    └── postmortem.md    # Stage 6: only if something went wrong in production
```

**Choose the slug once and never rename it.** The stage-latency metrics use it to match up the
commits, and a reader four months later uses it to find the reasoning behind a change.

## Lifecycle

| Artifact | Written by | Accepted by | When to commit it |
|---|---|---|---|
| `intent.md` | the originator, with Claude | the product owner | on its own. The commit timestamp is the Stage 1 measure |
| `spec.md` | the product owner, with Claude and the policy skills | the product owner, plus the tech lead for higher-risk changes | beside the intent |
| `plan.md` | the engineer, in plan mode | the engineer, after questioning it | **before** implementing |
| `review.md` | the reviewer subagent | the person who triages the findings | with the change |
| `postmortem.md` | the on-call engineer or service owner | the service owner | with the eval it produces |

## Rules

- **Commit each artifact separately from the code.** Putting `intent.md` in the same commit as the
  implementation destroys the metric and, more importantly, destroys the evidence that the thinking
  came first.
- **Never rewrite the history of an artifact.** A specification that changed is a specification with
  a second commit. The revision history is the record of what the organisation decided and when.
- **Keep open questions in the file.** An artifact with no open questions has usually hidden
  something rather than resolved it.
- **Do not skip a stage because the change is small.** A one-line fix gets a one-paragraph intent.
  It does not get no intent. That is how the audit trail develops gaps exactly where someone will
  later need it.

## How this fits with what you already have

**ADRs.** A `spec.md` describes *this* change. An architecture decision record describes a
constraint that everything after it inherits. When a specification makes a decision of that kind, it
says so, and the ADR is written at the same time, in your existing ADR directory with your existing
numbering. The `adr-authoring` skill handles this.

**A ticketing system (Jira, ServiceNow, Azure DevOps).** There are three workable arrangements. Pick
one deliberately, because the failure is having two sources of truth with no link between them.

1. **The repository is the source of truth.** The markdown is authoritative. The ticket references
   the commit.
2. **The ticket is the source of truth.** The markdown is a working copy, read at the start of a
   session and written back through an MCP connector (an integration that lets Claude read and write
   the ticketing system).
3. **Links only.** The minimum that works. Every artifact carries the ticket ID. Every ticket
   carries the commit SHA. Neither is authoritative, but nothing is orphaned.

**An existing requirements or design process.** Keep it. Run the artifact chain alongside it for one
real change, compare what each produced, and let the team decide. A process replaced by instruction
from above tends to be performed rather than used.
