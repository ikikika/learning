# Agent-configuration tests (evals)

These tests check **the configuration that steers Claude**: `CLAUDE.md`, the skills and the hooks.
They do not test the product. When someone edits a skill, these tests tell you whether the edit made
things worse. Each test is called an eval.

> **These are not your product tests.** If this repository already scores an AI feature it ships,
> keep that suite where it is. It cannot tell you whether last week's edit to `CLAUDE.md` made
> Claude worse at working here. Use separate directories, separate owners and separate checks.

## Running

```bash
kit/evals/run.sh                    # the whole suite
kit/evals/run.sh --case artifact-chain
```

Each case runs in a **temporary git worktree** (a separate checkout) created from `HEAD`, so a case
that writes files never changes the repository. The worktree is removed afterwards, whether the case
passes or fails. The repository must be committed and clean before a worktree can be created.

Needs `claude`, `jq`, `git`, and working Claude Code authentication (`ANTHROPIC_API_KEY` in CI).

## Writing a case

One JSON file per case in `cases/`. Use the `eval-authoring` skill, which contains the rules.

```json
{
  "id": "no-double-money",
  "description": "Money must be BigDecimal, never double — CLAUDE.md conventions. From INC-4412.",
  "prompt": "Add a discount field to the Order model and a method that applies it.",
  "allowed_tools": "Read,Edit,Glob,Grep,Bash",
  "checks": [
    { "type": "file_contains",     "path": "src/model/Order.java", "pattern": "BigDecimal discount" },
    { "type": "file_not_contains", "path": "src/model/Order.java", "pattern": "double discount" },
    { "type": "command",           "run": "make test" }
  ]
}
```

### Check types

| Type | Passes when |
|---|---|
| `file_contains` | `path` exists and matches the extended regular expression in `pattern` |
| `file_not_contains` | `path` does not exist, or does not match `pattern` |
| `file_exists` | `path` exists |
| `file_unchanged` | `git diff` is empty for `path`. The agent did not touch it |
| `command` | `run` exits with code 0 |
| `command_fails` | `run` exits with a non-zero code. **This is how you prove a hook blocks something** |
| `output_contains` | the final assistant message matches `pattern`, ignoring case |

### The rules that matter

- **One behaviour per case.** A case that asserts five things tells you something broke, but not
  what.
- **Check the outcome, not the transcript.** Prefer `file_contains` over `output_contains`. Checking
  what Claude *said* tests its phrasing, not its behaviour.
- **Prove that hooks block.** A hook is only tested by a case that attempts the forbidden action and
  expects it to fail. `file_unchanged` and `command_fails` exist for this.
- **Confirm the case fails when the safeguard is removed.** A case that passes both with and without
  the thing it protects is testing nothing. This is the most common defect in a new suite. Check it
  once, deliberately, for every case you add.
- **Keep cases fast and repeatable.** No network access, no dependence on the clock, no
  assumptions about ordering. Anything that needs a full running system belongs in a scheduled run,
  not the pull request run.

## The three shipped cases are examples

Cases `001` to `003` show the three basic shapes: an instruction in `CLAUDE.md`, a hook that must
block, and the artifact chain. **They make assumptions about your repository that are probably
wrong.** Read them, adapt them, and then start collecting real cases: 20 to 50 tasks drawn from
recent work, plus one for every production incident.

Three cases that run are worth more than fifty that were designed and never connected to CI.
