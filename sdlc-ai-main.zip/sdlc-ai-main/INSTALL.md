# Installation

## Requirements

`git`, `bash`, `jq` and `yq`. The installer checks for each one and stops with a clear message if
any is missing. The hooks also need `jq` when they run. A hook that cannot read the tool call it is
checking blocks that call rather than allowing it, so a missing `jq` shows up as blocked actions.

## Quick start

```bash
# 1. Preview what would happen. This writes nothing.
install/install.sh --target /path/to/repo --profile trunk-local --dry-run

# 2. Install the recommended first-week modules
install/install.sh --target /path/to/repo --profile trunk-local \
  --modules claude-md,skills,hooks,agents

# 3. Later, install everything else
install/install.sh --target /path/to/repo --profile trunk-local
```

## Options

| Flag | Default | What it does |
|---|---|---|
| `--target <path>` | *required* | The repository to install into. Must be a git repository. |
| `--profile <name>` | `trunk-local` | `trunk-local` or `pr-github`. See [`docs/05-profiles.md`](docs/05-profiles.md). |
| `--modules <a,b,c>` | all | Which modules to install. See the table below. |
| `--artifacts-dir <dir>` | `sdlc` | The directory that holds the intent, spec and plan files. |
| `--dry-run` | off | Print everything the installer would do, and write nothing. |
| `--force` | off | Continue even if `.claude/` is listed in `.gitignore`. |

## Modules

| Module | What it installs | When to adopt it |
|---|---|---|
| `claude-md` | A `CLAUDE.md` starting template, plus the verification and artifacts sections | week 1 |
| `skills` | The six skills, into `.claude/skills/` | week 1 |
| `hooks` | The guard scripts, into `.claude/hooks/`, registered in `.claude/settings.json` | week 1 |
| `agents` | The verifier, reviewer and spec-critic subagents, into `.claude/agents/` | week 1 |
| `commands` | `/intent`, `/spec`, `/plan`, `/review` and `/close-loop` | week 2 |
| `artifacts` | `sdlc/README.md` and the artifact templates | week 2 |
| `review` | `REVIEW.md` | month 2 |
| `evals` | The `evals/` test harness and three example cases | month 3 |
| `ci` | `agent-evals.yml`, plus the Stage 5 files for your profile | month 3 |
| `maintain` | `.sdlc-ai/bands.yaml` and `scripts/sdlc/watch-band.sh` | month 4 |

The recommended order, and the reasons for it, are in
[`docs/02-adoption-path.md`](docs/02-adoption-path.md).

## How the installer treats files you already have

The installer **merges. It never overwrites your work.**

| Destination | What happens |
|---|---|
| A file that does not exist | It is copied in. |
| `CLAUDE.md` | **Never rewritten.** A section between marker comments (`<!-- sdlc-ai:begin verification -->` and `<!-- sdlc-ai:end verification -->`) is appended. If the section already exists, it is replaced in place. Every other line is left as it was. |
| `.claude/settings.json` | Merged with `jq`. Objects are merged key by key. Lists are combined and duplicates removed, keeping the original order. Re-running never registers a hook twice and never reorders an entry you added. |
| `.sdlc-ai/bands.yaml` | Created only if it does not exist. Your tuned values are never replaced. |
| Any other kit file that already exists with different content | If the kit installed it and you have not edited it, it is updated. Otherwise the new version is written next to it as `<file>.sdlc-ai-new` and the installer reports the conflict. **Your file is not modified.** |

Before changing any file in place, the installer copies the original to `.sdlc-ai/backups/`. That is
what lets `uninstall.sh` restore files exactly.

### The `.gitignore` check

The installer **refuses to run** if `.claude/` is listed in `.gitignore`, and prints the fix:

```gitignore
# Agent configuration is reviewed code — only these are local
.claude/settings.local.json
.claude/worktrees/
```

This is a hard stop rather than a warning because the failure would otherwise be silent. Everything
would appear to install, but none of it would be shared, reviewed or visible in a diff. Pass
`--force` to install anyway.

## Re-running and upgrading

Running the installer a second time changes nothing. Every file reports `unchanged`. To upgrade
after pulling a new version of the kit, run the installer again. Files you have not edited are
updated. Files you have edited are left alone, and the new version is written beside them as
`.sdlc-ai-new`.

`.sdlc-ai/manifest.lock` records the kit version, the profile, the modules, a hash of every file
installed, and every file that was modified in place.

## Switching profiles

```bash
install/install.sh --target /path/to/repo --profile pr-github
```

The previous profile's Stage 5 files are removed, unless you have edited them, and the new profile's
files are installed. Nothing outside Stage 5 changes.

**One manual step.** The old profile's hook registration stays in `.claude/settings.json`, because
the installer will not remove entries from a file you may have edited by hand. It prints the entry
you need to remove.

## Uninstalling

```bash
install/uninstall.sh --target /path/to/repo --dry-run
install/uninstall.sh --target /path/to/repo
```

Files the kit created and you have not modified are removed. `CLAUDE.md` and `.claude/settings.json`
are restored from their backups. **Anything you edited is left in place and reported.** The
uninstaller never deletes your work.

## After installing

1. **Fill in the verification section of `CLAUDE.md`** with your real build, test and lint commands,
   and what their output looks like when they pass. This is what lets a Claude session check its own
   work. It takes about ten minutes and has the highest return of any step here.
2. **Edit `REVIEW.md`.** Start with the *Do not report* list, then the limit on minor comments.
3. **Configure the hooks** through the files in `.sdlc-ai/`:

   | File | Format | Effect |
   |---|---|---|
   | `protected-paths.txt` | one glob pattern per line | `protect-paths.sh` blocks edits to matching paths |
   | `test-patterns.txt` | one extended regular expression per line | replaces the default rule `protect-tests.sh` uses to recognise test files |
   | `format-command.txt` | a single command | `format-after-edit.sh` runs it after every edit |
   | `production-gate.txt` | one extended regular expression per line | defines which commands count as a production deployment (`pr-github` profile) |

4. **Run the full chain on one real change**: `/intent`, then `/spec`, then `/plan`. Commit all
   three files. A completed example that people can read explains the process better than any
   description.
5. **Adapt the examples.** The `secure-api-review` skill contains another organisation's security
   rules, and the cases in `evals/cases/` make assumptions about your repository that are probably
   wrong.

## Distributing to many repositories with the plugin

Once one repository is working, the `.claude/` part of the kit can be distributed as a Claude Code
plugin. Policy skills then update from one central place instead of being copied into each
repository.

```bash
/plugin marketplace add <your-internal-git-url>/sdlc-ai
/plugin install sdlc-ai@ey-sdlc-ai
```

First, set the marketplace source in `.claude-plugin/marketplace.json` to your internal git URL.

**The plugin includes** the six skills, the three subagents and the five commands.

**The plugin does not include** the following. Keep using the installer for them.

- **Hooks.** They must be registered in the repository's own `settings.json` with paths relative to
  `${CLAUDE_PROJECT_DIR}`, and they read their configuration from the repository's `.sdlc-ai/`
  directory.
- **CI workflows, artifact templates, `REVIEW.md` and the `.gitignore` fix.** None of these live
  under `.claude/`.

The plugin and the installer both read the same files under `kit/`, so there is one source of truth.

## Enterprise controls

`kit/enterprise/managed-settings.json` is **deliberately not installed by the installer**. Managed
settings are deployed by IT through device management software, outside the repository, because a
control that an engineer can edit does not control that engineer. See
[`kit/enterprise/README.md`](kit/enterprise/README.md).

## Troubleshooting

**"jq is required to merge settings.json".** Install `jq`. The hooks also need it at run time. A
hook that cannot read the tool call it is checking blocks the call rather than allowing it.

**A hook blocks something it should not.** Read the message it printed. It names the rule. To change
the rule, edit the matching file in `.sdlc-ai/`. To override it once, use the environment variable
documented in the hook's header comment (`SDLC_ALLOW_TEST_EDITS=1` or
`RELEASE_APPROVAL=<reference>`).

**`*.sdlc-ai-new` files have appeared.** You edited files that the kit also ships. Compare each one
with your version, take what you want, and delete the `.sdlc-ai-new` file. This is the intended
workflow, not an error.

**Nothing happens when I type `/intent`.** Either the `commands` module is not installed, or
`.claude/` is listed in `.gitignore` and the files are not where the session expects them.
