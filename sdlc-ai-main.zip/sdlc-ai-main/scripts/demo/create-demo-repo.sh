#!/usr/bin/env bash
#
# Create a throwaway repository for demonstrating the sdlc-ai kit.
# The runbook that uses it is docs/07-demo-on-a-fresh-repo.md.
#
#   create-demo-repo.sh --target <dir>
#
# The directory must not already exist. The result is a tiny Python project with a passing test
# suite, a short CLAUDE.md carrying one data-protection rule, and a demo policy skill that
# conflicts with that rule. Agent configuration under .claude/ is version-controlled from the start.
# Nothing here is real. Delete the directory and re-run to reset.
set -euo pipefail

TARGET=""
while [ $# -gt 0 ]; do
  case "$1" in
    --target) TARGET="$2"; shift 2 ;;
    -h|--help) sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done
[ -n "$TARGET" ] || { echo "--target is required. Run with --help." >&2; exit 2; }
[ ! -e "$TARGET" ] || { echo "$TARGET already exists. Remove it first; this script only creates from scratch." >&2; exit 1; }
for dep in git python3 make; do
  command -v "$dep" >/dev/null 2>&1 || { echo "missing dependency: $dep" >&2; exit 2; }
done

mkdir -p "$TARGET/app" "$TARGET/tests" "$TARGET/.claude/skills/customer-self-service"
cd "$TARGET"
git init -q -b main
git config user.email >/dev/null 2>&1 || git config user.email "demo@example.invalid"
git config user.name  >/dev/null 2>&1 || git config user.name  "sdlc-demo"

# ── The toy application ──────────────────────────────────────────────────────
: > app/__init__.py
: > tests/__init__.py

cat > app/claims.py <<'DEMO_CLAIMS_EOF'
"""A deliberately tiny claims module, used to demonstrate the sdlc-ai kit. Not a real system."""

_CLAIMS = {
    "CLM-1001": {"claimant": "A. Patel", "status": "received"},
    "CLM-1002": {"claimant": "J. Okafor", "status": "under review"},
    "CLM-1003": {"claimant": "M. Rossi", "status": "paid"},
}


def claim_status(claim_id: str) -> str:
    """Return the internal status of a claim. Raises KeyError for an unknown claim."""
    return _CLAIMS[claim_id]["status"]
DEMO_CLAIMS_EOF

cat > tests/test_claims.py <<'DEMO_TESTS_EOF'
import unittest

from app.claims import claim_status


class ClaimStatusTests(unittest.TestCase):
    def test_known_claim_returns_its_status(self):
        self.assertEqual(claim_status("CLM-1001"), "received")

    def test_unknown_claim_raises(self):
        with self.assertRaises(KeyError):
            claim_status("CLM-9999")


if __name__ == "__main__":
    unittest.main()
DEMO_TESTS_EOF

# Makefiles need a real tab; printf keeps that explicit.
printf '.PHONY: all test\n\nall: test\n\ntest:\n\tpython3 -m unittest discover -v\n' > Makefile

# ── CLAUDE.md: two lines the installer must keep, and one rule the spec will collide with ─────
cat > CLAUDE.md <<'DEMO_CLAUDE_EOF'
# sdlc-demo

A throwaway claims-status module used to demonstrate the sdlc-ai kit. Not a real system.

## Commands

- Test: `make test` (ends with `OK`)

## Conventions

- Python 3, standard library only. No third-party packages.
- Claim references look like `CLM-1001`.
- **Personal data rule (DP-3).** A claimant's name, address or bank details must not be shown to
  anyone who has not been authenticated, and must never appear in logs or error messages.
  Owner: Data Protection Officer (demo).
DEMO_CLAUDE_EOF

# ── A demo policy skill. Rules 1 and 2 are in deliberate tension with DP-3 above. ─────────────
cat > .claude/skills/customer-self-service/SKILL.md <<'DEMO_SKILL_EOF'
---
name: customer-self-service
description: DEMO POLICY. Applies the customer self-service standard whenever designing or changing anything a claimant uses directly, including claim status lookups, notifications and customer-facing messages.
---

# Customer self-service standard (demo)

> Demo policy written for the sdlc-ai walkthrough. It is deliberately in tension with the
> data-protection rule in CLAUDE.md so that Stage 2 has a real conflict to flag.

1. **No login for status.** A claimant must be able to check a claim's status using only the claim
   reference printed on their confirmation letter. Creating an account or signing in is not required.
2. **Show whose claim it is.** A status response includes the claimant's name, so the person can see
   they are looking at the right claim.
3. **Plain language.** Status messages are full sentences a customer can act on, not internal state
   names. "under review" becomes "We are reviewing your claim."
4. **An unknown reference is not an error.** An unknown claim reference gets a polite message and a
   way to contact us, never a stack trace or an error code.

## If you cannot satisfy a rule

Say so, name the rule, and route the conflict to the policy owner.

**Policy owner:** Customer Experience lead (demo)
DEMO_SKILL_EOF

# ── .gitignore: only the genuinely local agent state is ignored ───────────────────────────────
cat > .gitignore <<'DEMO_IGNORE_EOF'
__pycache__/
*.pyc

# Agent configuration is reviewed code — only these are local
.claude/settings.local.json
.claude/worktrees/
DEMO_IGNORE_EOF

git add -A
git commit -qm "Demo baseline: tiny claims module with a passing test suite"

echo "Created $TARGET"
echo
make test 2>&1 | tail -3
echo
echo "Next: follow docs/07-demo-on-a-fresh-repo.md."
