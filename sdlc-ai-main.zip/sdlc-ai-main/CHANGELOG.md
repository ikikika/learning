# Changelog

Each target repository records the kit version it installed in `.sdlc-ai/manifest.lock`. Re-running
the installer upgrades it.

## 0.1.0 (2026-08-30)

First release. Covers all six stages of the [AI-Native SDLC
Playbook](https://claude.com/blog/the-ai-native-sdlc-playbook).

**Kit**
- Six skills: `intent-capture`, `spec-authoring`, `implementation-plan`, `adr-authoring`,
  `eval-authoring`, and `secure-api-review` (an example policy skill).
- Three subagents: `verifier`, `reviewer`, `spec-critic`.
- Five commands: `/intent`, `/spec`, `/plan`, `/review`, `/close-loop`.
- Five hooks: `protect-tests`, `protect-paths`, `no-remote-push` (trunk-local profile),
  `production-gate` (pr-github profile), `format-after-edit`. Each one blocks the action if it
  cannot read its input.
- Artifact templates: `intent.md`, `spec.md`, `plan.md` and `postmortem.md`, plus `sdlc/README.md`.
- `REVIEW.md`, with named review passes, a definition of *Important*, and a limit on minor comments.
- The Stage 4b test harness for agent configuration (`run.sh`, `check.sh`, seven check types) and
  three example cases.
- CI: `agent-evals.yml`, `claude-review.yml`, `pre-merge-gate.sh`.
- Stage 6: `bands.yaml` with a tiered response, and `watch-band.sh`.
- `kit/enterprise/managed-settings.json`, documented but deliberately not installable.

**Installer**
- Safe to re-run. Merges with existing files and never overwrites them. Supports `--dry-run`,
  `--profile`, `--modules` and `--artifacts-dir`.
- Refuses to install when `.claude/` is listed in `.gitignore`.
- `.sdlc-ai/manifest.lock` and `.sdlc-ai/backups/` make upgrades, profile switches and uninstalls
  exact.

**Docs.** Why the kit exists, the six stages, an adoption path, the governance layers, the metrics,
the two profiles, a demonstration script, and a worked example that assesses a real repository.
