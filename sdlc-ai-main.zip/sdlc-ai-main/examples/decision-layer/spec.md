# Spec: human approval for irreversible actions, in Teams

Source: `intent.md` (2026-08-14)
Author: R. Mehta, with A. Novak (tech lead). Status: draft — blocked on C1
Date: 2026-08-18

## Summary

Adds a third PDP outcome alongside permit and deny: **pend**. A pended decision suspends the call,
raises an approval request to a named human over an outbound channel, and resumes or aborts on their
answer. The pause is durable, the approver is authenticated against the client's existing directory,
and the whole exchange lands in the audit record.

## Requirements

| # | Requirement | Traces to |
|---|---|---|
| R1 | A policy may return `pend` for a `write` / `irreversible` / `external_comms` action, carrying an approver reference and a timeout | Problem ¶1–2 |
| R2 | A pended call suspends without holding the caller's connection, and survives an orchestrator worker restart | Constraints ¶3 |
| R3 | The approval request reaches a named approver in Teams and shows what is being approved, for which tenant, and by which agent | Outcome ¶1 |
| R4 | Approve and reject are authenticated against the client directory; the identity is intersected with the same scopes as any other actor | Constraints ¶2 |
| R5 | An unanswered request expires at the policy-declared timeout and resolves as **deny**, not permit | Constraints ¶3 |
| R6 | Every state transition — pended, notified, approved, rejected, expired — is an audit event with actor, action, entity, timestamp | Outcome ¶2 |
| R7 | The channel is a swappable backend behind one Protocol; Slack is a second implementation, not a fork | Constraints ¶4 |
| R8 | Policies that today return permit or deny keep returning permit or deny, unchanged | Outcome ¶2 |

## Out of scope

- **Standing or batch approvals.** Raised in the intent's open questions; deliberately excluded. It
  converts a per-action gate into a time-boxed capability, which is a different control with a
  different blast radius and needs its own intent.
- **Approver delegation.** Depends on C2 below.
- **Approving from anywhere but Teams** — no web console, no email, no CLI.
- **Changing what any existing policy decides.**

## Design

`dl_pdp` gains `Decision.PEND` beside `PERMIT` and `DENY`, carrying `approver_ref` and `timeout_s`.
The rego evaluator and the Protocol both learn it; `Decision` is currently a two-valued enum, so this
is a breaking change to a contract type and the reason an ADR is owed.

The tool broker, on receiving `PEND`, writes an `ApprovalRequest` row, emits the request over the
channel Protocol, and returns a suspension to the orchestrator rather than a result. The Temporal
backend models the wait as a signal; the in-process backend polls. **The approval state lives in
Postgres, not in workflow memory** — that is what makes R2 hold across a restart.

`dl_approval` is a new workspace package holding the state machine and the `ApprovalChannel` Protocol.
The Teams implementation goes in `dl_approval/adapters/teams/` under the standing adapter-quarantine
rule; nothing outside that directory imports a Microsoft SDK.

Inbound approve/reject arrives at a control-plane endpoint, verifies the Teams-issued token against
the client directory's JWKS, and intersects the approver's scopes exactly as `dl_identity` does for
any other actor. There is no second identity path.

## Data and privacy

The approval request must carry enough for a human to decide and no more. The message body holds the
action name, the tenant, the agent identity, the resource **identifier**, and a correlation ID.

It does **not** carry subscriber names, addresses, MSISDNs or any field classified `pii`. Full context
is retrieved by the approver through the existing console, behind their existing authentication.

Audit events record the approver's directory identity and the decision. The message body is stored in
our audit store; the copy in the chat workspace is outside our retention control, which is C1.

## Policy conformance

| Policy | How this satisfies it |
|---|---|
| Invariant 1 — enforcement, not advice | `PEND` is enforced at the broker, before execution, on the same path as `DENY`. An unanswered request denies. |
| Invariant 2 — scope intersection once | The approver is intersected at the broker like any other actor. No second identity path. |
| Invariant 3 — tenant isolation | `ApprovalRequest` is tenant-scoped; the approver's tenant is checked before the request is shown. Needs a `tests/tenant-isolation/` case. |
| Invariant 5 — portable telemetry | The pending span stays open across the wait; approve/reject are span events. |
| Invariant 7 — open standards | The channel sits behind a Protocol; Teams is one adapter. |
| Data classification standard | No `pii`-classified field enters the message body. |

## Concerns and conflicts

**C1 — Audit completeness against no-PII-in-chat. BLOCKING.**
Invariant 6's audit story wants the record of what was approved to be complete and ours. The client's
data-handling constraint says subscriber data must not enter a chat workspace we do not control. These
are both satisfiable for the *fields*, but not for the *message*: the message is stored in the client's
Microsoft tenant under their retention policy, not ours, so part of the approval exchange sits outside
our audit boundary regardless of what the body contains.

Options: (a) accept it, and state in the audit record that the chat copy is client-retained —
cheap, and makes the boundary explicit rather than implicit; (b) send only a correlation ID and force
every approver into the console — satisfies both cleanly, and is very likely to be ignored in practice
because it makes the fast path slow; (c) run our own approval surface, which is a much larger change
and re-opens the identity question.

Recommendation is (a). **Owner: EY data protection lead — not yet named. This spec cannot be accepted
until they have.**

**C2 — Delegation. Non-blocking; descopes cleanly.**
The intent asks who approves when the named approver is away. The client's change process has a
delegation model, but it is attached to change tickets rather than to identities, so it is not directly
reusable. Modelling delegation properly is comparable in size to this whole change.

Proposed: ship without delegation, with R5's expiry as the safety net, and raise delegation as its own
intent. **Owner: A. Novak (tech lead) — accepted this on 2026-08-18.**

**C3 — Budget hard-stop during a pending approval. Non-blocking, needs a decision.**
Invariant 6 says budgets hard-stop. If the engagement's budget stops while an approval is pending, the
approver may approve an action that can no longer run. Cheapest correct behaviour is to expire the
request on budget stop and tell the approver why. **Owner: A. Novak.**

## Verification

- An acceptance test in `tests/acceptance/` driving the full governed path with a policy that pends,
  including the restart in the middle.
- A `tests/tenant-isolation/` case: an approver in tenant A cannot see or answer tenant B's request.
- An eval case proving expiry resolves as deny.
- `make all` green, `make opa-test` green with the extended rego.

## Decisions needing a record

**An ADR is owed.** `Decision` becomes three-valued, which changes contract 3.6's Protocol and every
implementation of it. The ADR must state what a caller that does not understand `PEND` must do — the
answer is treat it as `DENY`, fail closed — and that the second PDP engine deleted by ADR-0090 is not
coming back to help here. Take the next free number from `decisions/` at the time of writing.

## Open questions carried forward

- Delegation — carried to C2, descoped, owner accepted.
- Budget hard-stop — carried to C3, owner assigned, undecided.
- Standing/batch approvals — explicitly out of scope. Needs its own intent if operations still want it.
- New: is one timeout per policy enough, or does it need to vary by action class? Deferred until there
  is evidence from an engagement.
