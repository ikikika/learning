# Intent: human approval for irreversible actions, in Teams

Author: R. Mehta (engagement lead, telco O2A).
Status: accepted
Date: 2026-08-14

## Problem

The telco order-to-activate agent is allowed to place an order with the downstream TMF640 system. It
is a write, it is irreversible, and the PDP either permits it or refuses it. There is no third answer.

On the last engagement this cost us twice. Once the policy was tight, the agent was refused on eleven
legitimate orders in a fortnight, and an engineer had to re-run each by hand. Once it was loosened to
stop that, and an agent placed an order against the wrong subscriber account — caught the same day,
but only because someone happened to look.

The client's own change process has a named approver for exactly this class of action. We cannot use
them, because there is nowhere for the agent to ask.

## Proposed outcome

An irreversible action the policy is not confident about pauses and asks a named human, in the tool
they already sit in all day. The human sees enough to decide, answers yes or no, and the run continues
or stops. The whole exchange is in the audit record.

Approvals that are genuinely routine should stay automatic. This is for the middle band that today has
to be either blocked or waved through.

## Affected users and systems

Approvers in client operations teams (Teams today; Slack asked for by two other engagements). The PDP,
the tool broker, the orchestrator — the pause has to survive a worker restart. The audit trail. The
consultants who configure policy per engagement.

## Constraints

- **No new PII surface.** Subscriber data must not sit in a chat workspace we do not control. This is
  the constraint that killed the previous attempt at this.
- **No new identity system.** The approver's identity has to come from the client's existing directory.
  Anyone able to approve in chat must be someone who could approve today.
- Must work when the approver does not answer — an approval request that hangs forever is a stalled
  order, which is the thing we are trying to prevent.
- Teams first. Slack must not require re-architecting.

## How we would know it worked

The eleven-refusals-a-fortnight number goes to roughly zero without the policy being loosened, and no
irreversible action reaches a downstream system without either a policy decision or a named human
behind it.

## Open questions

- Who is the approver when the named one is on leave? The client has a delegation model for change
  tickets; is it reusable here, or does it have to be modelled separately?
- What happens to an approval that is still pending when the engagement's budget hard-stops?
- Is "approve" per-action, or can an approver grant a short-lived standing approval for a batch? The
  operations team asked for the second. It sounds like a scope expansion with a blast radius.
