# Plan: human approval for irreversible actions, in Teams

Source: `spec.md` (2026-08-18, C1 resolved 2026-08-21 — option (a), signed off by the data protection lead)
Author: A. Novak. Status: accepted
Date: 2026-08-22

## Approach

Add `PEND` to the PDP decision type, make the tool broker suspend on it, and put the approval state in
Postgres so the wait survives a restart. The channel is a Protocol with one Teams adapter. Slack is not
built, only kept possible.

**Rejected — hold the caller's connection open and block.** Simplest by a wide margin, and wrong: it
fails R2 on any restart, and ties an approval that may take an hour to an HTTP timeout measured in
seconds.

**Rejected — model approval as a workflow activity in the Temporal backend.** Neat where Temporal is
the backend, and it would leave the in-process orchestrator with no approval support at all. The state
belongs below the orchestrator seam, not inside one implementation of it.

**Rejected — a new `dl_hitl` service.** ADR-0009's consolidation argument still applies; this is a
package inside the control-plane API, not a fifth deployable.

## Files that change

| Path | New/Modified | What happens |
|---|---|---|
| `services/pdp/dl_pdp/contract.py` | modified | `Decision` gains `PEND`; `PendDetails` (approver_ref, timeout_s) |
| `services/pdp/dl_pdp/engines/opa/pdp.rego` | modified | rego may emit `pend` with the two fields |
| `services/pdp/dl_pdp/engines/opa/pdp_test.rego` | modified | rego cases for pend, and for a malformed pend falling back to deny |
| `sdk/dl_approval/` | new | the package: state machine, `ApprovalChannel` Protocol, `ApprovalRequest` model, `py.typed` |
| `sdk/dl_approval/adapters/teams/` | new | the Teams adapter. **The only place a Microsoft SDK is imported.** |
| `services/tool_broker/dl_tool_broker/service.py` | modified | on `PEND`: persist, emit, return a suspension instead of a result |
| `services/orchestrator/dl_orchestrator/backends/temporal/workflow.py` | modified | wait on an approval signal |
| `services/orchestrator/dl_orchestrator/in_process.py` | modified | poll the approval store |
| `services/control_plane/routes/approvals.py` | new | inbound approve/reject; verifies the directory token against JWKS |
| `alembic/versions/<rev>_approval_requests.py` | new | the `approval_requests` table, tenant-scoped |
| `tests/acceptance/test_approval_pend.py` | new | the governed path with a pending approval, including a restart |
| `tests/tenant-isolation/test_approval_tenant.py` | new | tenant A cannot see or answer tenant B's request |
| `evals/approval_expiry_gate.py` | new | expiry resolves as deny |
| `decisions/adr-NNNN-pdp-pend-decision.md` | new | **take the next free number from `decisions/` when you write it** |
| `pyproject.toml`, `Makefile` | modified | `dl_approval` into workspace members, isort first-party, and `PKGS` |
| `docs/policy-reference.md` | modified | document `pend` |

## Order of work

1. **`Decision.PEND` + `PendDetails` in `dl_pdp`, and the rego.** Nothing consumes it yet; every
   existing caller still sees permit/deny. `make all` green here.
2. **The ADR.** Before anything depends on the three-valued type, not after.
3. **`dl_approval`: model, migration, state machine, Protocol.** No channel yet, no broker wiring.
   Unit-tested in isolation. Wire it into `PKGS` in this step — an unlisted package is ungated.
4. **Broker suspension on `PEND`**, with a test double for the channel. The acceptance test lands
   here and passes without Teams existing.
5. **Both orchestrator backends resume from the store.** The restart case in the acceptance test
   starts passing at this step.
6. **The Teams adapter and the inbound endpoint.** The first step that touches a vendor SDK, and the
   last one that can break anything already working.
7. **Tenant-isolation test, expiry eval, `docs/policy-reference.md`.**

## Risks

| Risk | Likelihood | What we do about it |
|---|---|---|
| A caller that does not understand `PEND` treats it as permit — fail-open on an irreversible action | Low, catastrophic | The ADR states it; the Protocol default and the broker both treat an unknown decision as deny. A rego test asserts a malformed pend denies. This is the risk the whole change lives or dies on. |
| `Decision` is a contract type in `sdk/`; accelerators import it | Certain | Additive to the enum, no field removed. Grep for exhaustive matches on `Decision` and fix each before step 4. |
| The approval store becomes a second source of truth for run state | Medium | It holds approval state only. The orchestrator remains authoritative for the run. Stated in the ADR. |
| Temporal signal handling diverges from the in-process poll | Medium | The acceptance test runs against both backends, as `test_temporal_backend.py` already does. |
| Teams delivery fails silently and the request expires as deny | Medium | Delivery failure is its own audit event and surfaces in the console. Expiry-as-deny is correct but must be distinguishable from "nobody answered". |
| `dl_approval` is added to the workspace but not to `PKGS`, so mypy never sees it | Medium | Step 3 does both. This has already happened once in this repo (`dl_workflow`). |

## Proof

- [ ] `tests/acceptance/test_approval_pend.py` — pend → notify → approve → resume, and pend → restart →
      approve → resume, against both orchestrator backends
- [ ] `tests/tenant-isolation/test_approval_tenant.py` — approver in tenant A gets 404, not 403, for
      tenant B's request
- [ ] `services/pdp/dl_pdp/engines/opa/pdp_test.rego` — pend emitted; malformed pend denies
- [ ] `evals/approval_expiry_gate.py` — an unanswered request resolves as deny
- [ ] `make all` green, and `make opa-test` green
- [ ] Manual: place a real order through the telco O2A pack, approve it in Teams, and confirm the
      message body carries no `pii`-classified field

## Decision record owed

**Yes.** `Decision` becomes three-valued: what `PEND` means, that an unknown decision is treated as
`DENY`, that approval state lives in Postgres rather than workflow memory, and that the channel is a
swappable adapter. **Read `ls decisions/` for the next free number when you write it — do not use a
number quoted anywhere in this plan or in `spec.md`.**
