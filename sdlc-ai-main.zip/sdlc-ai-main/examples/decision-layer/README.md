# Worked example: `hitl-approval-to-teams`

A completed set of artifacts for a real Decision Layer roadmap item: *HITL to Teams/Slack*
(human-in-the-loop approval through Microsoft Teams or Slack), from Phase 2 of `ROADMAP.md`. This is
reference material. Nothing installs it.

Read the files in order. They show what the templates look like when used properly, and in
particular what Stage 2 is *for*: `spec.md` records two conflicts between policies that would
otherwise have surfaced in review, after the code was written.

| File | Stage | What to notice |
|---|---|---|
| [`intent.md`](intent.md) | 1 | Written by an engagement lead, not an engineer. No design in it. Open questions kept in. |
| [`spec.md`](spec.md) | 2 | Requirements traced back to the intent. **Two flagged conflicts, each with a named owner.** An ADR identified as needed. |
| [`plan.md`](plan.md) | 3 | Real file paths, a work order where the code still builds after each step, risks including a rejected alternative, and a proof section that names the tests. |

The change itself was not built. These are the artifacts as they would stand at the moment the plan
is accepted and implementation begins.
