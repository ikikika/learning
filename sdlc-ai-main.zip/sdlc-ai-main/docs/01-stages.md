# The six stages, and what each one produces

This document defines the terms used throughout the kit. Every other document assumes you have read
it.

The process is a **loop**, not a straight line. Each stage produces a file, called an **artifact**,
that is committed to git and read by the next stage. Together those artifacts (the intent, the
specification, the plan, the code change and the review findings) form the audit trail. There is no
separate compliance document to maintain, because the git history is the record.

```
  ┌──────────────────────────────────────────────────────────────────┐
  │                                                                  │
  ▼                                                                  │
1 PLAN ──▶ 2 DESIGN ──▶ 3 BUILD ──▶ 4 TEST ──▶ 5 DEPLOY ──▶ 6 MAINTAIN
intent.md   spec.md      plan.md    green      review        breach
                                    gates      findings      ──▶ intent.md
```

Terms used below:

- A **skill** is a set of instructions that Claude loads when a task matches the skill's
  description. It shapes what Claude does but does not restrict what it can do.
- A **hook** is a script that Claude Code runs before or after a tool call. A hook can block the
  call.
- A **subagent** is a separate Claude session with a narrow job and a restricted set of tools.
- A **command** is a slash command, such as `/intent`, that runs a predefined prompt.
- A **gate** is a check that must pass before work moves to the next stage.

---

## Stage 1: Plan. Produces `intent.md`

**What changes.** The person who had an idea records it, in a conversation with Claude, as a
version-controlled markdown file. It is not a ticket and not a set of workshop notes.

**Who.** The originator, who is often not an engineer. The product owner approves or rejects it.

**Kit files.** The `intent-capture` skill, the `/intent` command, and `sdlc/templates/intent.md`.

**The gate.** A human product owner accepts or closes the intent. Never automate this step. It is
the only place where the organisation decides whether something is worth building.

**Early measure.** Time from the first conversation to a committed `intent.md`, read directly from
git. Expect this to fall from weeks to hours.

---

## Stage 2: Design. Produces `spec.md`

**What changes.** Requirements and design stop being two phases run by two teams. One Claude session
produces both, guided by **skills** that encode your brand, security, compliance and user-experience
policies. Policy is applied while the specification is written, instead of being discovered in a
review three weeks later.

**Who.** The product owner. Policy owners are brought in for anything the specification flags as a
conflict.

**Kit files.** The `spec-authoring` skill, the `spec-critic` subagent, the `/spec` command, and
`sdlc/templates/spec.md`. Your own policy skills sit alongside the `secure-api-review` example.

**The gate.** Product owner sign-off, with every flagged conflict assigned to a named policy owner
before engineering starts.

**Early measure.** Time between the `intent.md` commit and the `spec.md` commit.

---

## Stage 3: Build. Produces `plan.md`, then the code change

**What changes.** Four things at once.

| | What it is | Kit files |
|---|---|---|
| **Plan mode** | Claude reads the repository but cannot edit anything until you accept a written plan. Design review moves to before code generation, where corrections are cheap. | The `implementation-plan` skill and the `/plan` command |
| **`CLAUDE.md`** | The context a new team member needs: commands, conventions, architecture, and the mistakes your team actually makes. Claude reads it in full at the start of every session, so keep it to about a page. | `kit/claude-md/` |
| **Skills** | Team knowledge that must be applied consistently, written down and version-controlled. | `kit/claude/skills/` |
| **Hooks** | The enforcement layer underneath a skill. A skill makes the right action likely. A hook makes the wrong action fail. | `kit/claude/hooks/` |

**A rule for `CLAUDE.md`.** When Claude makes the same mistake twice, add the correction to the
file. If it only happened once, it was probably noise.

**A rule for choosing between a skill and `CLAUDE.md`.** Write a skill for knowledge that must be
applied consistently across many sessions and repositories. Keep in `CLAUDE.md` what only this
repository needs on day one.

**Parallel sessions.** Independent tasks run in separate git worktrees, which are separate checkouts
of the same repository. Start with two or three. The limit is how many streams of work one person
can genuinely review, not how many the machine can run.

**Early measure.** The share of changes that merge after the first implementation attempt.

---

## Stage 4: Test. Produces passing checks and test cases

Two separate things belong here, and teams often confuse them.

**4a. Give Claude a way to check its own work.** The session runs the build, the tests, the linter,
or a screenshot comparison, and fixes what it broke before a person sees the change. This needs one
command that exits with a non-zero code on failure (for example `make all` or `npm test`), listed in
`CLAUDE.md` with an example of passing output, and an explicit instruction that running it is part
of being done.

For a bug fix, the order matters. Write the failing test **first**. Confirm it fails for the
expected reason. Commit it. Then ask for the fix. Use a hook to stop the agent editing the test to
make it pass. The `protect-tests.sh` hook does exactly that.

**4b. Regression tests for the agent configuration.** This is the part almost everyone skips.
`CLAUDE.md`, your skills and your hooks are inputs to a model. Change them and Claude's behaviour
changes. So they need regression tests like any other code. In this kit, such a test is called an
**eval**: a prompt, plus checks that define an acceptable result. Evals run without human
interaction in CI whenever `CLAUDE.md` or anything under `.claude/` changes.

> **Product tests are not agent-configuration tests.** If your repository already scores an AI
> feature it ships (decision-layer's `make eval` does this), that is a product quality check. It
> tells you nothing about whether last week's edit to a skill made Claude worse at working in your
> codebase. You need both.

Every production incident should become a permanent eval. That is how the suite pays for itself.

**Early measure.** The first-attempt CI pass rate for changes written by agents, and the eval pass
rate over time.

---

## Stage 5: Deploy. Produces review findings

**What changes.** Review runs in both directions. Claude reviews incoming changes, and Claude
addresses review findings on its own work. Rules are enforced as the agent acts, not audited
afterwards. The agent does everything up to the production gate and nothing past it.

**The review policy is a file.** `REVIEW.md` at the repository root lists the review passes to run,
defines what counts as *Important* versus a minor comment (a "nit"), sets a limit on the number of
minor comments, and lists what not to report. Without a limit on minor comments, you get a review
nobody reads.

**Separation of duties is required.** The agent that wrote a change cannot be the thing that
approves it. How the approval gate works depends on your profile. See
[`05-profiles.md`](05-profiles.md). In `trunk-local`, a coordinator reads the change and the full
test suite passes on the merged result. In `pr-github`, branch protection requires a designated code
owner's approval.

**Approval hooks belong here, not in Build.** A hook that stops to ask a person for approval during
Build puts that person back on the critical path and serialises all the parallel work you just set
up.

**Early measure.** Time to first review, and the share of findings resolved without a person
touching the branch.

---

## Stage 6: Maintain. Produces a new `intent.md`

**What changes.** The loop closes. A script watches a production metric. When the metric leaves its
expected range (its "control band"), the script starts a Claude session with no person involved.
Claude diagnoses the problem, acts only through pre-approved routes, and writes its findings as an
`intent.md`. That file re-enters the process at Stage 1.

**A tiered response keeps this safe.** Detection is a plain script with no model involved. The
response depends on how far the metric has moved, measured in standard deviations (σ) from its
baseline. The tiers are version-controlled in `bands.yaml`.

| Deviation | Action |
|---|---|
| 1σ | Log only |
| 2σ | Start Claude in **read-only** mode to diagnose |
| 3σ | Claude may act: open a change into the review gate, or run a pre-approved runbook |

An agent that can act at 1σ will act far too often. An agent that can only log at 3σ adds nothing.

**Early measure.** Time from a metric leaving its band to an `intent.md` appearing in the triage
queue, compared with how long the incident-to-action path used to take.

---

## The artifact chain in one table

| Artifact | Written at | Read by | Location |
|---|---|---|---|
| `intent.md` | Stage 1 | Stage 2 | `sdlc/<slug>/intent.md` |
| `spec.md` | Stage 2 | Stage 3 | `sdlc/<slug>/spec.md` |
| `plan.md` | Stage 3 | Stages 3 and 5 | `sdlc/<slug>/plan.md` |
| the code change and tests | Stages 3 and 4 | Stage 5 | your branch |
| review findings | Stage 5 | `CLAUDE.md` | the review thread, or `sdlc/<slug>/review.md` |
| ADR | any stage | everything after it | your existing ADR directory |
| `postmortem.md` | Stage 6 | Stage 1 and the evals | `sdlc/<slug>/postmortem.md` |

The `<slug>` is a short, lowercase, hyphenated name for the change, such as
`claims-status-self-service`.

**Where ADRs fit.** An architecture decision record (ADR) records a decision that outlives a single
change: a new backend, a schema, a system boundary. A `spec.md` describes one change. When a
specification makes a decision of that kind, it says so, and the ADR is written at the same time.
The `adr-authoring` skill applies your organisation's ADR format and, importantly, reads the ADR
directory to find the next free number instead of trusting a number quoted in a document.
