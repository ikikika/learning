# Adoption path

The stages are independent. You do not need to adopt all six at once, and a team that tries usually
ends up with none of them. This document gives the order that pays back fastest, based on what most
repositories are missing.

## Two prerequisites

**1. Is `.claude/` version-controlled?** Check your `.gitignore`. Many repositories ignore the whole
directory as "local agent configuration". That is reasonable until agent configuration becomes
something you want reviewed, owned and visible in diffs. If `.claude/` is ignored, none of this
kit's skills, hooks or subagents can be shared, and the installer will stop and tell you.

The fix keeps the genuinely local files local and version-controls everything else:

```gitignore
# Agent configuration is reviewed code — only these are local
.claude/settings.local.json
.claude/worktrees/
```

**2. Is there one command that verifies the repository?** You need a single command that exits with
a non-zero code on failure, such as `make all` or `npm test`. Without it, Stage 4 has nothing to
work with, and every Claude session hands you unverified work. If you do not have one, build it
first. It is worth more than anything else in this kit.

---

## Week one: Build and Test (Stages 3 and 4a)

This has the fastest return, and it needs no process change from anyone outside the engineering
team.

```bash
install/install.sh --target /path/to/repo --profile trunk-local --modules claude-md,skills,hooks,agents
```

- **A `CLAUDE.md` with a verification section.** List the commands, describe what passing output
  looks like, and state that running them is part of being done. If you already have a `CLAUDE.md`,
  the installer appends one marked section and leaves the rest of your file alone.
- **Two hooks that nobody will object to.** `protect-tests.sh` stops an agent editing a test to make
  a failure disappear. `protect-paths.sh` blocks edits to generated or frozen directories. Both turn
  a rule people already agree with into a rule that is applied every time.
- **The `verifier` subagent.** It runs the change and reports what it saw. It is not allowed to fix
  anything, which is what makes its report trustworthy.

**How to tell it worked.** Watch the share of sessions that hand back a change with the checks
already passing. Track it informally for two weeks before you build any tooling for it.

## Weeks two to four: the artifact chain (Stages 1, 2 and 3)

```bash
install/install.sh --target /path/to/repo --modules artifacts,skills,commands
```

Introduce the sequence `intent.md`, then `spec.md`, then `plan.md`. Do it on **one real change**,
from start to finish, and commit all three files. A completed example that someone can read explains
the process better than any description, which is why this repository ships
`examples/decision-layer/`.

Do not write a full set of templates for your organisation first. Use the shipped templates on a
real change, notice which fields you never fill in, and delete those.

## Month two: Review (Stage 5)

```bash
install/install.sh --target /path/to/repo --modules review
```

Write `REVIEW.md`. Three things decide whether it works.

1. **Named review passes.** Bugs, security, and conformance with the specification. Tag every
   finding with the pass that produced it.
2. **A definition of *Important*.** Reserve it for findings that break behaviour, leak data or
   breach a policy. Everything else is a minor comment, and the file should say so.
3. **A limit on minor comments.** Report five, then give a count of the rest. A reviewer with no
   limit produces output nobody reads. That is worse than no reviewer, because it uses up the team's
   willingness to try.

Then tune the file monthly. Rate the findings, and put recurring patterns into `CLAUDE.md`.

## Month three: agent-configuration tests (Stage 4b)

```bash
install/install.sh --target /path/to/repo --modules evals,ci
```

By now you have skills and hooks that people depend on, and no way to tell whether editing them made
things worse. Collect 20 to 50 real tasks from recent work. Write each one as a prompt plus checks.
Then require the tests to pass before any change to `CLAUDE.md` or `.claude/` can merge.

Start with three cases. Three cases that actually run are worth more than fifty that were designed
and never connected to CI.

## Month four onwards: close the loop (Stage 6)

```bash
install/install.sh --target /path/to/repo --modules maintain
```

Pick **one** metric with a stable rolling baseline. CI failure rate is usually the easiest, because
you already have the data and nothing in production is at risk. Set the bands, connect the trigger,
and run at the log and diagnose tiers only for a month before you let anything act at the 3σ tier.

---

## The order to avoid

Do not start with Stage 6. It is the most impressive stage to demonstrate and the least valuable to
adopt first. An automated loop that feeds findings into a process that cannot yet handle them
produces a queue of `intent.md` files nobody reads, and the experiment gets abandoned.

Do not start with the agent-configuration tests either. They protect the agent configuration against
regressions. Write the configuration first, or there is nothing to protect.

## Rolling out to many repositories

Once one repository works, distribute the `.claude/` part as a plugin (see
[`../INSTALL.md`](../INSTALL.md)) so that policy skills update from one central place. Keep using
the installer for everything the plugin cannot carry: CI workflows, artifact templates, `REVIEW.md`,
and the `.gitignore` fix.
