# Governance: guidance, enforcement, and locked controls

A rule can live in three places. Choosing the wrong one is the most common mistake teams make when
they adopt this process. The three places are not alternatives. They are layers, and an important
control usually uses more than one.

The playbook calls these layers *advisory*, *deterministic* and *immovable*. This document uses
plainer names and gives the playbook's term once, in brackets.

| Layer | Mechanism | What it does | Who owns it | Who can change it |
|---|---|---|---|---|
| **Guidance** (advisory) | `CLAUDE.md`, skills | Makes the right action *likely* | Tech lead, policy owner | Anyone, through code review |
| **Enforcement** (deterministic) | Hooks, `.claude/settings.json` | Makes the wrong action *fail* | Platform engineer | Anyone with write access to the repository |
| **Locked controls** (immovable) | Managed settings, deployed by IT | Makes the wrong action *impossible* | IT or platform administrator | Only IT |

## Guidance: skills and `CLAUDE.md`

A skill is a set of instructions that Claude loads when a task matches the skill's description. It
shapes what the model does. It does not restrict what the model *can* do. That is the right layer
for most team knowledge, because most knowledge depends on context rather than being absolute:
*prefer this pattern*, *check that document*, *this API has four possible states*.

**Write a skill when** the knowledge must be applied consistently across many sessions and by many
people, and must be updated centrally when the policy changes.

**Keep it in `CLAUDE.md` when** it is what this repository needs on day one: the build command, the
directory layout, the two mistakes new team members make.

**Put it in the prompt when** it is true for this task only.

The common failure is treating guidance as if it were enforcement. "Never push from an agent
session" in a contributing guide reads like a rule but behaves like a suggestion. It will be
followed most of the time, which is worse than failing loudly, because you stop checking.

## Enforcement: hooks

A hook is a script that Claude Code runs around a tool call. It sees the tool's input and can block
the call. Exiting with code 2 stops the action and sends whatever the hook wrote to standard error
back to Claude. That message is worth writing carefully, because it is read by the thing that has to
change course.

Use a hook when a policy must hold **without exception**:

- protected paths, such as generated code, frozen packages and vendor directories;
- test files during a bug fix, so that a failing test cannot be edited into a passing one;
- remote operations that are supposed to be a person's decision;
- credentials, which must never appear in a diff.

**Every hook should have a matching skill, and every skill that states a hard rule should have a
matching hook.** The skill explains *why* and shapes behaviour before the attempt. The hook catches
the attempt. A hook with no skill produces an agent that keeps trying the same blocked action. A
skill with no hook produces a rule that is usually followed.

**Where hooks must not go: approval prompts during Build.** A hook that stops and asks a person for
permission in the middle of a session puts that person back on the critical path and serialises
every parallel session you were running. Approval gates belong in Stage 5, at the point of
deployment.

### Worked example: from prose to hook

decision-layer's `CLAUDE.md` and its batch coordinator command both say, in capitals, *never push*.
It is the right rule for that repository. Work is merged locally into the main branch, and a person
pushes by hand after review. But the rule is written in prose, so it holds only while everyone is
reading carefully. `kit/claude/hooks/no-remote-push.sh` is the same rule as an enforced check: `git
push`, `git remote add` and every `gh` subcommand that writes all fail, with a message explaining
what to do instead. The prose stays. It is now the guidance layer, which explains why. The hook is
what makes the rule hold.

## Locked controls: managed settings

Anything an engineer can edit does not control that engineer. For regulated work, the controls that
matter are deployed by IT through device management software to a path outside the repository.
Claude Code refuses to widen them from any project file or command-line flag.

- `permissions.deny` and `permissions.allow`: keep secrets unreadable, block outbound network
  access, and pre-approve the safe everyday commands.
- `allowManagedPermissionRulesOnly` and `disableBypassPermissionsMode`: no project file and no
  command-line flag can widen the rules.
- `sandbox` with `failIfUnavailable`: operating-system isolation that refuses to start rather than
  run without isolation.
- `credentials`: deny reads of `~/.ssh` and `~/.aws`, and remove tokens from sandboxed environments.
- `allowManagedHooksOnly`: your approval gates are the *only* hooks. Nothing local can replace them.
- `disableSideloadFlags` and `strictKnownMarketplaces`: every skill, agent and MCP server must come
  through an approved marketplace.
- `allowManagedMcpServersOnly`: the set of available tools is an allow-list, not something Claude
  discovers.
- `requiredMinimumVersion`: refuse to run on a client version that has not been approved.

`kit/enterprise/managed-settings.json` is a template for this. **The installer will not install
it**, deliberately. Putting it in the repository would teach exactly the wrong lesson about where
controls live.

## Separation of duties

The agent that wrote a change must not be the thing that approves it. This holds in every profile.
Only the mechanism differs.

- **`pr-github`**. Branch protection requires approval from a designated code owner, and the agent's
  identity is not one. The agent's changes become pull requests. There is no direct path to the main
  branch.
- **`trunk-local`**. Agent branches are never pushed and never merged by the agent. A coordinator
  (the person responsible for integrating the work) reads the change, merges it locally, and re-runs
  the full test suite *on the merged result*. That is a stronger check than any per-branch CI run,
  because it tests all the concurrent changes together. The coordinator then pushes.

Both are valid. What is not valid is an agent whose work reaches the main branch without a named
person having looked at it.

## What is recorded, and where the audit trail is

You do not build an audit trail separately. You commit one as you work.

| Question an auditor asks | Where the answer is |
|---|---|
| Why was this built? | `sdlc/<slug>/intent.md`, with its author and commit timestamp |
| Who approved it? | The commit or merge that accepted the intent and the specification |
| Which policies applied? | The versions of the skills in the tree at that commit |
| What was the plan, and did the change follow it? | `plan.md` compared with the merged change |
| What did the review find? | The review findings, in the review thread or in `review.md` |
| What was blocked, and when? | Hook decisions in the session log or the OpenTelemetry export |
| Why was this deployment allowed? | The release approval that the production gate required |
