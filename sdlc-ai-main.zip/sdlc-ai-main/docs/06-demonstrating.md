# Demonstrating the process in twenty minutes

A script for showing the process to another EY team. The process is a loop, so the demonstration has
to end where it started. That is the part people remember.

For a demonstration that starts from an empty throwaway repository and includes the install, use
[`07-demo-on-a-fresh-repo.md`](07-demo-on-a-fresh-repo.md) instead.

**Prepare in advance.** Have a repository with the kit installed and a small, real change chosen.
Have a second terminal open. Do not demonstrate on a repository where you have never run the checks.

## The plan

| Minutes | Step | What the audience sees |
|---|---|---|
| 0 to 2 | The problem | One slide or one sentence: writing code stopped being the slowest step, and the process around it did not change |
| 2 to 5 | Stage 1 | You *talk* to Claude about a problem. It asks you questions. An `intent.md` appears and is committed |
| 5 to 8 | Stage 2 | Claude turns `intent.md` into `spec.md` with a policy skill loaded, and **flags a conflict** between two policies |
| 8 to 13 | Stage 3 | Plan mode. Claude cannot edit files. You question the plan, change it, and *then* accept it |
| 13 to 16 | Stage 4 | The session runs the checks itself. Then you ask it to edit a test, and the hook blocks the edit |
| 16 to 18 | Stage 5 | `/review` following `REVIEW.md`. Three passes, with minor comments limited |
| 18 to 20 | Stage 6 | A metric leaves its band and a new `intent.md` is written. Point back at the file from minute 2 |

## The three moments that matter

Everything else is context. These are what people repeat afterwards.

**1. The flagged conflict (minute 7).** Prepare a specification where two of your policies genuinely
disagree. A data-handling rule against a user-experience rule is the easiest. Claude writes the
specification, says it cannot satisfy both, and names them. Say out loud: *that conversation used to
happen in a review, six weeks later, after the code was written.*

**2. The blocked test edit (minute 15).** Ask Claude to make a failing test pass. Watch it try to
edit the test file. Watch the hook stop it. Then show `protect-tests.sh`. It is nine lines long.

> "That rule was already in our contributing guide. It was followed about as often as people were
> reading carefully. Now it is applied every time."

This is the moment the governance argument becomes concrete. Give it time.

**3. Closing the loop (minute 19).** Trigger a band breach and let it write an `intent.md`. Open the
file from minute 2 beside it. Same template, same directory, same shape. The loop is closed, and
nobody typed the second one.

## Questions you will be asked

**"Does the AI approve its own work?"** No, and the design prevents it. Show the profile. In
`pr-github`, branch protection and the agent's identity. In `trunk-local`, the coordinator's test
run on the merged result. Then show a hook blocking a push. Answer this question with the mechanism,
not with reassurance.

**"What if the model changes and everything behaves differently?"** That is exactly why Stage 4b
exists. `CLAUDE.md`, skills and hooks are model inputs, so they have regression tests. Show
`agent-evals.yml` and the `paths:` trigger that runs it.

**"Isn't this a lot of files?"** Show `install.sh --dry-run`. The whole thing is one command, and
the first-week subset is four modules.

**"Our repository does not work like the blog post."** Neither does decision-layer, which is the
reference implementation. Show [`05-profiles.md`](05-profiles.md) and the `trunk-local` profile. The
kit adapts to how you merge. The separation-of-duties requirement is the only thing that does not
change.

**"Where does our existing Jira, ADR or contract process go?"** There are three options, and the
middle one is usually right. The repository is the source of truth. The existing system is the
source of truth and the markdown is a working copy. Or, most commonly, both are kept and linked,
with the ticket ID in the artifact and the commit SHA in the ticket. Pick one deliberately. The
failure is having two sources of truth with no link between them.

## Things to avoid

- **Do not demonstrate Stage 6 first.** It is the most impressive and the least adoptable. A team
  that leads with the automated loop is asked to justify autonomy before it has shown the
  safeguards.
- **Do not hide the flagged conflict.** A demonstration where the AI agrees with everything teaches
  the audience that the AI agrees with everything.
- **Do not run `--dangerously-skip-permissions` on screen.** You will spend the rest of the session
  discussing that flag instead of the process.
