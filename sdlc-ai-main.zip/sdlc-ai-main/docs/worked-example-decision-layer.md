# Worked example: assessing `decision-layer`

A real repository measured against the playbook, with the installer's dry-run output. Written on
**2026-08-30** against `decision-layer` at commit `252092e`.

**Nothing was written to that repository.** Everything below came from `--dry-run`, and the evidence
is at the end.

---

## The repository in one paragraph

Decision Layer is EY's control layer for AI agents. It is designed to be thin and to work with any
underlying runtime. It is written in Python 3.12 as a `uv` workspace, using FastAPI. It has seven
stated rules that must always hold (the repository calls them invariants), ten contracts, 83
architecture decision records (ADRs), eight CI checks, a `make all` target that runs six of them
locally, pre-commit hooks, and a `CONTRIBUTING.md` that is unusually specific about how work is
merged. This is a well-run repository, and the assessment below should be read in that light. The
gaps are the ones a well-run repository has, not the ones a neglected one has.

## Stage by stage

| Stage | What is already there | What is missing |
|---|---|---|
| **1 Plan** | Goals in `ROADMAP.md`. Batch specifications in `docs/*-batch-*.md`. `docs/platform-next-milestones.md`. | No `intent.md`. Work is described in terms of *what will be built* from the first sentence, so nothing records *why* separately from *what*. There is no way for a non-engineer to record an idea. The roadmap items came from client engagements, so the originators exist. They have nowhere to write. |
| **2 Design** | `contracts/3.1` to `3.10` and 83 ADRs. These are excellent, and better than most of what this kit would install. | No per-change `spec.md`. More importantly, the contracts are read *by a person, before* building, as `CLAUDE.md` says explicitly, rather than applied *by Claude, during* building. There are no policy skills, so the seven invariants are prose that a session may or may not have taken in. |
| **3 Build** | Worktrees are already standard and already used for parallel work. `.claude/commands/` holds real batch-coordinator specifications. `CLAUDE.md` is 138 lines and unusually good. | No `.claude/skills/`, `.claude/hooks/` or `.claude/agents/`. No committed `plan.md`. Plan mode is used, but its output is not kept, so there is nothing to compare the merged change against. |
| **4 Test** | Eight CI checks. `make all` locally. `tests/tenant-isolation/` is treated as untouchable. A product eval check with baselines held in a registry (ADR-0018) that fails the build on regression. A strong feedback loop by any standard. | `CLAUDE.md` names the commands but not what passing output looks like, and does not say that running them is part of being done. **Nothing prevents an agent editing a test to make it pass.** The batch command asks it not to, in prose. And the `evals/` suite is a *product* eval. It scores the shipped agent. Nothing regression-tests `CLAUDE.md` or the command files themselves. |
| **5 Deploy** | The coordinator merges locally and re-runs `make all` **on the merged result**, which is a stronger check than per-branch CI. A pull request template exists. Push discipline is strict and deliberate. | No `REVIEW.md`. Review covers whatever the coordinator thinks to look for on the day. No reviewer subagent. The no-push rule is prose. |
| **6 Maintain** | OpenTelemetry is invariant number 5. `logs/` accumulates eval runs. | No `bands.yaml`, no detection script, and no path from a production finding back to an intent. Findings from a running engagement re-enter the backlog when someone remembers them. |

## The two findings that matter

### 1. `.claude/` is ignored by git

`.gitignore`, line 37:

```gitignore
# local agent config / scratch
.claude/
```

This was a reasonable decision that has quietly stopped being right. It was made when `.claude/`
held a settings file and some scratch files. It is now the reason agent configuration cannot be
reviewed, owned, diffed or shared. It has three consequences, in increasing order of seriousness.

- `.claude/commands/agent-builder-batch.md`, the instruction set for a batch of twelve parallel work
  items and a critical coordinator specification, is not tracked by git. A single `git clean -fdx`
  would delete it, and nobody else has a copy.
- Nothing this kit installs under `.claude/` would be version-controlled, so the installer stops
  rather than pretending to work.
- The playbook's fifth principle, that configuration is code and is reviewed and tested like code,
  cannot hold here at all.

The fix is narrow, because the original reason for the rule is real: `.claude/worktrees/` genuinely
does hold whole checkouts of the repository.

```gitignore
# Agent configuration is reviewed code — only these are local
.claude/settings.local.json
.claude/worktrees/
```

### 2. The most important rules are guidance only

`CLAUDE.md` and `.claude/commands/agent-builder-batch.md` both say, in capitals:

> **NEVER PUSH.** No `git push`, no `gh pr create`, no remote operation of any kind, this session.

It is the right rule for this repository, and it is enforced by everyone reading carefully. That
works until it does not, and when it fails, the failure is silent and affects the remote. The same
rule as `no-remote-push.sh` is enforced every time:

```
BLOCKED: git push

Remote write operations are the user's to make, by hand, after they have reviewed the change.
Work here merges locally into the trunk; nothing is pushed from a session.
```

The prose does not go away. It becomes the layer that explains *why*, which is what stops a session
looking for another route. The same argument applies to "do not let a session weaken a check to make
it pass", which `protect-tests.sh` enforces, and to the adapter-quarantine rule (adapters must stay
in their own directories), which `protect-paths.sh` could enforce.

**This is the clearest example in either repository of the distinction described in
[`03-governance.md`](03-governance.md), and it is why that document exists.**

## What the installer would do

```console
$ install/install.sh --target …/decision-layer --profile trunk-local --dry-run

sdlc-ai v0.1.0 → …/decision-layer
  profile:  trunk-local
  DRY RUN — nothing will be written

Blocked: .claude/ is gitignored in this repository
  …
  Then re-run. Use --force to install anyway; the files will not be version-controlled.
```

It stops, as designed. Past that stop, the full plan is **35 files, 0 conflicts**:

```console
claude-md — CLAUDE.md scaffold, plus the verification and artifacts blocks
  = CLAUDE.md (kept — create-if-absent) (unchanged)
  → append block 'verification' to CLAUDE.md (138 existing lines untouched)
  → append block 'artifacts' to CLAUDE.md (138 existing lines untouched)

skills   → 6 files into .claude/skills/
agents   → 3 files into .claude/agents/
commands → 5 files into .claude/commands/
hooks    → 5 files into .claude/hooks/, registered in a new .claude/settings.json
artifacts→ sdlc/README.md + 4 templates
review   → REVIEW.md
evals    → evals/README.md, run.sh, check.sh, 3 cases
ci       → .github/workflows/agent-evals.yml, ci/local/pre-merge-gate.sh
maintain → .sdlc-ai/bands.yaml, scripts/sdlc/watch-band.sh

Result
  Dry run. 35 file(s) would be written, 0 conflict(s) would need a manual merge.
  Nothing was written to …/decision-layer.
```

Note the **zero conflicts**. The 138-line `CLAUDE.md` is not touched except to gain two marked
sections. The existing `.github/workflows/ci.yml` is not touched at all. `.claude/commands/` gains
five files beside the three batch coordinator files already there.

There are two overlaps the installer does *not* hit, but a person should think about.

- **`evals/`.** decision-layer already has an `evals/` directory holding product eval checks. The
  kit would add `evals/README.md`, `run.sh`, `check.sh` and `cases/` beside them. No filename
  collides, but two different kinds of eval would share a directory. Install with `--modules`
  excluding `evals`, and put the agent-configuration suite in `evals/agent/` instead.
- **`sdlc/` next to `docs/`.** The `docs/` directory is deliberately small and organised into three
  groups. A new top-level `sdlc/` directory would sit beside `contracts/`, `decisions/`, `packs/`
  and `evals/`, which is this repository's established pattern for content directories. That is the
  right place for it.

## A step-by-step adoption path for this repository

**Step 0: the `.gitignore`.** Nothing else is possible until this is done. Three lines, with a
comment explaining why, because the original comment was right when it was written.

**Step 1: track what already exists.** Before installing anything, commit the three
`.claude/commands/` files that are currently untracked. They are more valuable than anything this
kit would add, and they are the least safe files in the repository.

**Step 2: hooks, and only hooks.** `no-remote-push.sh` and `protect-tests.sh`. Both encode rules the
team has already agreed to and written down, so there is nothing to debate. The only change is that
the rule now holds when nobody is watching. This is the cheapest possible demonstration that the
enforcement layer is real.

```bash
install/install.sh --target …/decision-layer --profile trunk-local --modules hooks
```

Then add `.sdlc-ai/protected-paths.txt` for the adapter-quarantine rule, which is currently enforced
by one acceptance test after the fact:

```
services/*/adapters/**
services/*/backends/**
services/*/engines/**
```

**Step 3: the verification section.** The commands section of `CLAUDE.md` lists `make all` but does
not say what passing output looks like or that running it is part of being done. Ten minutes of
work, and it is the change most likely to reduce the number of times a session reports success it
did not observe.

**Step 4: one policy skill.** Not six. Take the seven invariants and write the two that are violated
most often, adapter quarantine and scope-intersection-once, as skills that load when the relevant
code is touched. The other five stay in `CLAUDE.md`, where they belong.

**Step 5: `REVIEW.md`.** The coordinator's review of the merged result is the gate. Right now, what
that review looks for is in the coordinator's head. Writing it down makes it repeatable, and lets
the `reviewer` subagent do the mechanical passes first.

**Step 6: the artifact chain, on one change.** `intent.md`, `spec.md` and `plan.md` for one real
Phase 2 roadmap item. [`examples/decision-layer/`](../examples/decision-layer/) is exactly this,
written for the *HITL to Teams* item (human-in-the-loop approval through Microsoft Teams), so the
team can read a completed set before committing to the process.

**Step 7: agent-configuration tests, in `evals/agent/`.** A separate directory with a separate
owner. Three cases: the adapter-quarantine skill loads, `protect-tests.sh` blocks a test edit, and a
session runs `make all` before reporting done.

**Later: Stage 6.** Not before the earlier steps. An automated loop that feeds findings into a
process that cannot handle them produces a queue nobody reads, and the experiment gets abandoned.

## One thing the kit should learn from this repository

decision-layer's `CLAUDE.md` has a section this kit's template did not have, and should:

> ## Source of truth (read before editing a service)
> **The contract and the ADRs are authoritative.**

A table of *which document answers which question* is more useful than a prose architecture section.
It is what stops a session confidently reading a planning document that the code overtook two months
ago. The `docs/archive/` convention ("job finished, or overtaken by the code. Kept, never deleted")
is a better answer to documentation going stale than anything in the playbook.

## Evidence that nothing was written

```console
$ git -C …/decision-layer rev-parse HEAD      # before
252092e235382a140118558df3941511957ffdac
$ git -C …/decision-layer rev-parse HEAD      # after
252092e235382a140118558df3941511957ffdac

$ diff <(status before) <(status after)
  <no differences>

$ find …/decision-layer -maxdepth 2 \( -name .sdlc-ai -o -name REVIEW.md -o -name sdlc \) | wc -l
0
```

The repository's three pre-existing untracked entries were the same before and after. Nothing was
added, modified or removed.
