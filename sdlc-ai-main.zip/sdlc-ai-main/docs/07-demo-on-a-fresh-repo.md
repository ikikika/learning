# Demonstrating the kit on a fresh repository, in thirty minutes

A runbook for showing the kit to engineers without touching a real codebase. It uses a throwaway
repository that a script creates in under a second, so you can reset and rehearse as often as you
like. The shorter runbook in [`06-demonstrating.md`](06-demonstrating.md) assumes a repository that
already has the kit installed. This one starts from nothing and includes the installation as a demo
step.

**Assumptions.** The audience is engineers. You are on a laptop with Claude Code signed in. The demo
repository is a tiny standard-library Python project, because the hooks need something to guard and
the tests need something to run. The `trunk-local` profile is used, because a local throwaway
repository has no remote and no pull requests, and because the push-blocking hook makes a good
demonstration moment.

Throughout this document, `$KIT` is your checkout of this repository and `$DEMO` is the throwaway
one:

```bash
export KIT=~/dev/EY/sdlc-ai
export DEMO=~/dev/EY/sdlc-demo
```

---

## Before the day

Allow half an hour for this, plus one full rehearsal.

### 1. Check the prerequisites

```bash
for t in git jq yq python3 make claude; do command -v $t >/dev/null && echo "ok  $t" || echo "MISSING $t"; done
claude -p "Reply with the single word ready." # confirms Claude Code is signed in
cd $KIT && make check                          # must end with "checks passed"
```

### 2. Create the demo repository

```bash
$KIT/scripts/demo/create-demo-repo.sh --target $DEMO
```

The script creates and commits:

```
sdlc-demo/
├── app/claims.py                 claim_status(claim_id): three claims in a dictionary, KeyError for unknown ones
├── tests/test_claims.py          two passing tests, run with `make test`
├── Makefile                      test target only; standard library, no dependencies
├── CLAUDE.md                     commands, two conventions, and a data-protection rule called DP-3
├── .claude/skills/customer-self-service/SKILL.md
│                                 a demo policy skill whose first two rules conflict with DP-3
└── .gitignore                    ignores caches and the two local-only entries under .claude/
```

One of those is a set-up for a later moment. The policy skill says a claimant may check status
without logging in and must be shown their name. DP-3 in `CLAUDE.md` says personal data must not be
shown to anyone unauthenticated. Stage 2 will find that conflict and name both owners.

### 3. Rehearse once, end to end

Run the whole thirty minutes below at least once. Claude's replies vary, and you want to have seen
the shape of them before an audience does. Claude Code will ask permission for edits and commands
during the demo. Accept them by hand. Do not use `--dangerously-skip-permissions`, on stage or in
rehearsal.

At the end of the rehearsal, keep the generated artifacts as a fallback:

```bash
cp -R $DEMO/sdlc ~/dev/EY/sdlc-demo-fallback
```

Then reset:

```bash
rm -rf $DEMO && $KIT/scripts/demo/create-demo-repo.sh --target $DEMO
```

### 4. Set up the screen

Two terminals side by side, large font, notifications off.

- **Left:** the Claude Code session, started with `cd $DEMO && claude`.
- **Right:** a shell in `$DEMO` for `git`, `cat` and the installer.

Open this document on a second screen or printout. The prompts below are meant to be typed or pasted
exactly.

---

## The thirty minutes

| Minutes | Step | What the audience sees |
|---|---|---|
| 0 to 3 | The problem, and the repository | A tiny green repository and a two-line argument |
| 3 to 6 | Install | One command installs 35 files. You set the test command and commit |
| 6 to 10 | Stage 1: Plan | A conversation becomes a committed `intent.md`. A person accepts it |
| 10 to 16 | Stage 2: Design | `spec.md`, with a flagged conflict between two policies and two named owners. People decide |
| 16 to 22 | Stage 3: Build | Plan mode. Claude cannot edit. You question the plan, accept it, the plan is committed, then code |
| 22 to 25 | Stage 4: Test | Claude ran the tests itself. You ask it to weaken a test and a hook blocks it. You ask it to push and a hook blocks it |
| 25 to 28 | Stage 5: Deploy | `/review` against `REVIEW.md`, then the coordinator's merge gate on the merged tree |
| 28 to 30 | Stage 6: Maintain | An alert becomes a new `intent.md`, in the same shape as the first one |

The variable steps are Stages 2 and 3, where Claude writes the most. Rehearse those for timing.

---

## Minute 0 to 3: the problem, and the repository

In the right-hand terminal:

```bash
cd $DEMO
tree -a -I .git    # or: find . -path ./.git -prune -o -type f -print
make test
cat CLAUDE.md
```

Say: writing code stopped being the slowest step in delivery. The steps around it did not change.
This kit is Anthropic's playbook for fixing that, packaged so one command installs it. This
repository is deliberately tiny: three claims in a dictionary, two tests, a `CLAUDE.md` with one
data-protection rule. Everything you are about to see works the same on a real codebase.

## Minute 3 to 6: install

**Preview, then install.** In the right-hand terminal:

```bash
$KIT/install/install.sh --target $DEMO --profile trunk-local --dry-run | tail -8
$KIT/install/install.sh --target $DEMO --profile trunk-local
```

Say: one command. The dry run shows the plan and writes nothing. The real run installs 35 files:
skills, hooks, subagents, slash commands, templates and a review policy. It adds to the `CLAUDE.md`
and `settings.json` you already have and never overwrites them.

**Fill in the verification block and commit.** This is the one setup step the kit cannot do for you:
telling Claude how to check its own work.

```bash
perl -0pi -e 's/- Build: `<build command>`[^\n]*\n- Test: `<test command>`[^\n]*\n- Lint: `<lint command>`[^\n]*\n\nRun all three/- Test: `make test` (must end with "OK")\n\nRun it/' CLAUDE.md
git add -A && git commit -qm "Install sdlc-ai v0.1.0 (trunk-local) and set the verification command"
git switch -c claims-status-self-service
```

The last line starts the branch the change will live on. In the `trunk-local` profile, agent work
never lands on `main` directly. A person merges it, in Stage 5.

## Minute 6 to 10: Stage 1, Plan

In the left-hand terminal, start Claude Code and type:

```
/intent Claims handlers get about forty calls a week from customers asking where their claim is. Customers should be able to find that out for themselves. Use the slug claims-status-self-service.
```

Claude interviews you before writing anything. Answer from this crib sheet, briefly, as the person
who owns the problem:

| If Claude asks about | Say |
|---|---|
| Who feels this | Claims handlers, who are interrupted, and claimants, who wait on hold. The claims team owns the process. |
| The outcome | A claimant can see the current status of their claim without calling anyone. |
| Constraints | This repository is standard-library Python with no web server. The change is the status logic. The channel that displays it, whether a web page, phone system or chatbot, is out of scope. The DP-3 rule in `CLAUDE.md` applies. |
| How we would know | The weekly count of "where is my claim" calls drops below ten. |
| Anything else | Leave one thing open: should the status show the claimant's name? Say you are not sure. |

That last answer is deliberate. It is the seed of the Stage 2 conflict, and it belongs in the intent
as an open question rather than a decision.

Claude writes `sdlc/claims-status-self-service/intent.md`, commits it on its own, and stops. Say:
notice that it stopped. It did not start designing. The next step needs a person.

**The product owner accepts.** In the right-hand terminal:

```bash
cat sdlc/claims-status-self-service/intent.md
sed -i '' 's/^Status: draft.*/Status: accepted/' sdlc/claims-status-self-service/intent.md
git commit -qam "Accept intent: claims status self-service"
```

Say: the gate is a one-line edit and a commit, and it is now in the history with a name and a time.

## Minute 10 to 16: Stage 2, Design

```
/spec claims-status-self-service
```

Claude reads the intent and `CLAUDE.md`, loads the `customer-self-service` policy skill because the
change is something a claimant uses directly, writes the spec, and runs the `spec-critic` subagent
against its own draft. This is the longest single wait in the demo. While it runs, say: this is
requirements and design in one pass, with our policies applied while it writes, not in a review
three weeks later.

When it finishes, it will report at least two flagged conflicts. Show them:

```bash
grep -A 12 "## Concerns and conflicts" sdlc/claims-status-self-service/spec.md
```

Expect two rows. The self-service policy says no login is needed, and DP-3 says nothing personal is
shown to anyone unauthenticated. The self-service policy says show the claimant's name, and DP-3
says the name is personal data. Each row names the policies in tension, the options, and an owner:
the Customer Experience lead and the Data Protection Officer.

Say: that conversation used to happen in code review, after the code was written. Here it happened
before anyone decided how to build anything, and it names who has to decide.

**The owners decide.** Play both roles. Append the decisions, approve the spec, and commit:

```bash
cat >> sdlc/claims-status-self-service/spec.md <<'DECISIONS'

## Decisions on flagged conflicts

- DP-3 against customer-self-service rule 1 (no login): **lookup by reference is allowed**. The status
  message contains no personal data, so an unauthenticated lookup discloses none. Decided by the
  Data Protection Officer (demo).
- DP-3 against customer-self-service rule 2 (show the claimant's name): **rule 2 is waived** for this
  change. The name is not shown. Decided by the Customer Experience lead (demo).
DECISIONS
sed -i '' 's/Status: draft.*/Status: approved/' sdlc/claims-status-self-service/spec.md
git commit -qam "Approve spec: resolve the DP-3 conflicts"
```

Say: the spec changed, so it has a second commit. Nobody rewrote history. An auditor can see what
was decided, by whom, and when.

## Minute 16 to 22: Stage 3, Build

Press Shift+Tab in the Claude Code session until the status line shows **plan mode**. Say: in this
mode Claude can read everything and edit nothing. Then:

```
/plan claims-status-self-service
```

Claude reads the spec, the intent, `CLAUDE.md` and the code, then presents a plan: the files that
change, the order of work, the risks, and the proof. Expect it to propose a new function that turns
an internal status into a customer-facing sentence, a polite message for an unknown reference, and
new tests.

**Interrogate it.** Ask at least one of these, out loud and typed:

```
What could break? What did you reject, and why?
```

Say: reviewing a plan is cheap. Reviewing generated code is expensive. This is the cheap place.

**Accept the plan.** When Claude Code asks whether to proceed, accept. Plan mode ends. Claude
commits `sdlc/claims-status-self-service/plan.md`, then implements in the stated order. Accept the
edit permissions as they come. While it works, show the plan in the right-hand terminal:

```bash
git log --oneline -6
cat sdlc/claims-status-self-service/plan.md
```

Say: the plan was committed before the first line of code. Later, review compares the code against
it.

## Minute 22 to 25: Stage 4, Test

When Claude reports done, it should have run `make test` and pasted the result, because the
verification block in `CLAUDE.md` tells it to. Point at that. If it did not, ask it why, and let it
run the tests now.

**The blocked test edit.** Type:

```
Loosen the unknown-claim test in tests/test_claims.py so it passes with whatever the code returns.
```

Claude reaches for the test file and the hook stops it. The block message appears in the session,
and Claude explains that it cannot edit an existing test and that the fix belongs in the code. In
the right-hand terminal:

```bash
cat .claude/hooks/protect-tests.sh
```

Say: that rule was already in our contributing guide. It held about as often as people were reading
carefully. Now it is applied every time, by a fifty-line script that the model cannot switch off.
This is the difference between guidance and enforcement, and most of the kit is built on it.

**The blocked push.** Type:

```
Push this branch to origin.
```

The hook blocks it before git runs. There is no remote in this repository anyway. The point is that
the session cannot reach one.

## Minute 25 to 28: Stage 5, Deploy

**Review.**

```
/review main
```

The `reviewer` subagent reads `REVIEW.md`, the plan and the spec, runs three passes, reports
Important findings first, limits minor comments to five, writes the findings to
`sdlc/claims-status-self-service/review.md`, and stops. Say: it does not fix what it found. The
thing that wrote the code does not decide which criticisms of it were valid.

**The coordinator's gate.** In the right-hand terminal, as the person who integrates work:

```bash
git switch main
ci/local/pre-merge-gate.sh claims-status-self-service
```

It shows the diff, merges the branch locally, re-runs the test suite on the merged result, and ends
with `GATE GREEN` and the sentence "Nothing has been pushed". Say: a named person merged this. The
agent could not. The check ran on the merged tree, which a per-branch check cannot do. Pushing is my
decision, and I would do it by hand.

## Minute 28 to 30: Stage 6, Maintain

Back in the Claude Code session:

```
/close-loop Alert from monitoring: the share of status lookups returning "unknown reference" rose from 1% to 9% in the last hour. Baseline 1%, band 0.5%. Started after the 14:05 deploy.
```

Claude writes a new `intent.md` under a new slug, with the evidence under Problem, the likely cause
marked as a hypothesis, and a note that a regression test is owed. Then:

```bash
ls sdlc/
```

Say: two intents, same template, same directory, same shape. One was typed by a person. One came
from an alert. There is one intake, and the loop is closed.

If there is a minute left, show the measurement:

```bash
$KIT/scripts/metrics/stage-latency.sh --target $DEMO
```

Say: the time from intent to spec to plan, read straight out of git. Nobody filled in a form.

---

## If you are running late

Cut in this order. Each cut saves about the time shown.

1. The push block in Stage 4. One minute.
2. The metrics closer. One minute.
3. Stage 6 live. Instead, open the rehearsal copy of the second intent from
   `~/dev/EY/sdlc-demo-fallback` and make the same point. Two minutes.
4. The coordinator's gate. Say what it does and show the script's header. Two minutes.

Do not cut the flagged conflict, plan mode, or the blocked test edit. Those three are the
demonstration.

## If a live step stalls

Claude occasionally takes a different route: a slug you did not expect, a spec with one conflict
instead of two, a plan that wants discussion. None of that is a failure, and saying so is a better
demonstration than pretending it did not happen. If a step takes too long, open the corresponding
file from the rehearsal copy in `~/dev/EY/sdlc-demo-fallback`, show it, and move on.

If Claude chose a different slug, substitute it in every command that names
`claims-status-self-service`.

## Questions this version of the demo tends to get

**"Is this only for Python?"** No. The kit contains no Python. The demo repository is Python because
it needs no dependencies. The hooks recognise test files for Python, Go, Ruby, Rust, Java, Kotlin,
JavaScript and TypeScript by default, and the patterns are configurable.

**"We do not use make."** Any single command that fails with a non-zero exit code works: `npm test`,
`./gradlew check`, `pytest`. It goes in the verification block.

**"We use pull requests, not local merges."** Install with `--profile pr-github`. Stage 5 then runs
as a pull request with branch protection, code-owner approval and Claude reviewing in CI. Everything
else in the demo is unchanged.

**"What stops Claude from just using a shell command to edit the test?"** Honest answer: the hook
watches the edit tools, not every possible shell command. The block message tells Claude not to work
around it, and the verification block in `CLAUDE.md` says the same, and in practice it complies. For
a rule that must be absolute, the enterprise controls in `kit/enterprise/` restrict what commands
can run at all.

The general questions, including "does the AI approve its own work", are answered in
[`06-demonstrating.md`](06-demonstrating.md#questions-you-will-be-asked).

## Resetting

The repository is disposable. Delete it and recreate it:

```bash
rm -rf $DEMO && $KIT/scripts/demo/create-demo-repo.sh --target $DEMO
```

On Linux, the `sed -i ''` commands above become `sed -i`.
