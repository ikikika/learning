# Profiles: `trunk-local` and `pr-github`

A profile is the set of Stage 5 (Deploy) files the installer puts in place. Stage 5 is the only
stage that varies, because it is the only stage that depends on how your team merges work.
Everything in Stages 1 to 4 and Stage 6 is the same in both profiles.

Choose a profile with `--profile` at install time. Choosing wrongly is not serious. Re-run the
installer with the other profile and it swaps the Stage 5 files. But choose deliberately rather than
accepting the default.

## `pr-github`

**Choose this if** work reaches the main branch through pull requests, you have or can enable branch
protection, and CI can run on a pull request.

| | |
|---|---|
| The gate | Branch protection, plus approval from a designated code owner |
| Where review runs | In CI, on the pull request, through `claude-review.yml` |
| Where findings go | Pull request comments. The agent addresses them when it is tagged |
| The deployment check | `production-gate.sh`. A production deployment requires a named release approval |
| Files installed | `ci/github/claude-review.yml`, `hooks/production-gate.sh`, `settings.d/profile-pr-github.json` |

**Separation of duties** comes from GitHub. The agent's identity cannot approve a pull request, and
there is no way to push directly to the protected branch.

## `trunk-local`

**Choose this if** work is merged into the main branch on a local machine by a coordinator, and a
person pushes by hand. Also choose it if remote operations are deliberately restricted for safety.

| | |
|---|---|
| The gate | A coordinator reads the change, merges it locally, and re-runs the full verification command **on the merged result** |
| Where review runs | Locally, through the `/review` command and the `reviewer` subagent, following `REVIEW.md` |
| Where findings go | `sdlc/<slug>/review.md`, committed with the change |
| The push check | `no-remote-push.sh`. Pushes, adding remotes, and `gh` commands that write are all blocked |
| Files installed | `ci/local/pre-merge-gate.sh`, `hooks/no-remote-push.sh`, `settings.d/profile-trunk-local.json` |

**Separation of duties** comes from the merge. An agent session cannot push and cannot merge its own
work. The coordinator is the approving person, and the test run on the merged result is the check.

### Why this profile is not a weaker option

It is easy to read `trunk-local` as "pull requests without the tooling". It is not. When work lands
as a batch of concurrent changes that depend on each other, the check that matters is the full test
suite on the **merged** result, with every change included. A per-branch pull request check cannot
give you that. Each branch can pass on its own and the merge can still fail.

decision-layer is the reference case. Agent sessions branch from the main branch in separate
worktrees, the coordinator merges locally and re-runs `make all` on the result, and `gh` is
deliberately not configured for the corporate remote. The playbook's Stage 5 requirements are met
there: a named person reviews before integration, the agent cannot approve its own work, and the
record is in the merge commits. They are just not met by GitHub.

## Switching profiles

```bash
install/install.sh --target /path/to/repo --profile pr-github
```

Re-running with a different profile removes the previous profile's Stage 5 files (they are recorded
in `.sdlc-ai/manifest.lock`) and installs the new ones. Nothing outside Stage 5 changes.

## If neither fits

If you merge through GitLab, Gerrit, or an in-house system, start from `trunk-local`. It makes the
fewest assumptions about the hosting service. Replace `ci/local/pre-merge-gate.sh` with your own
equivalent. The requirement the kit cares about is the one in
[`03-governance.md`](03-governance.md#separation-of-duties): a named person looks at the change
before it reaches the main branch, and the agent that wrote it is not that person.
