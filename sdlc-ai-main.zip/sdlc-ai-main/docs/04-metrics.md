# Metrics

The playbook pairs every stage with two kinds of measure.

- A **leading indicator** moves within days and tells you the practice is being used.
- A **lagging indicator** moves over months and tells you whether the practice worked.

Both matter. The common failure is to report only the leading indicators, because they are the
flattering ones.

Almost all of these measures come from git history. That is one of the reasons for committing the
artifacts.

## The full set

| Stage | Leading indicator | Lagging indicator |
|---|---|---|
| 1 Plan | Time from the first conversation to a committed `intent.md` | The share of intents that reach Stage 2. Edits to `intent.md` after the first `spec.md` exists |
| 2 Design | Time from the `intent.md` commit to the `spec.md` commit | `spec.md` commits dated after the first `plan.md`. That is, requirements changing after building started |
| 3 Build | The share of changes that merge after the first implementation attempt | Rework cycles per change. Whether the merged change still matches `plan.md` |
| 4 Test | First-attempt CI pass rate for changes written by agents. Eval pass rate | Review time per change. Change failure rate |
| 5 Deploy | Time to first review. Findings resolved without a person touching the branch | Defects caught before merge, compared with defects that reached production |
| 6 Maintain | Time from a metric leaving its band to an `intent.md` in the triage queue | The share of findings that become merged fixes. Repeat incidents |

## What the kit computes for you

Two scripts. Both are read-only, and both work from the git history of the target repository.

```bash
scripts/metrics/stage-latency.sh --target /path/to/repo
```

For every change directory under `sdlc/`, this reports the elapsed time between the commits that
first added `intent.md`, `spec.md` and `plan.md`. That is the leading indicator for Stages 1 and 2,
measured rather than estimated.

```bash
scripts/metrics/artifact-coverage.sh --target /path/to/repo --since 90.days
```

This reports the share of merges into the main branch that have a `plan.md` committed for them. It
is the most reliable measure of adoption. A team that says it follows the process and has 12%
coverage is not following the process.

## How to read the numbers

**Falling latency is not the result.** It only shows that the practice is being used. The result is
in the lagging column, as less rework and fewer defects reaching production, and it appears about a
quarter later. A team that reports "idea to intent fell from three weeks to four hours" and nothing
else has not yet measured anything useful.

**Watch the rework indicators most closely.** They are the ones that show the process going wrong.
Requirements changing after building starts means specifications are too thin to be useful. A merged
change that no longer resembles its `plan.md` means the plan review is not doing its job.

**Check coverage before latency.** The latency figures only describe the changes that have
artifacts. If coverage is 12%, the latency figures describe 12% of the work.

**Always pair a speed number with a quality number.** Changes merged per engineer per week means
nothing without the rework rate beside it. The two move together when something is wrong, and
showing them together is what makes that visible.

**Do not use these in performance reviews.** Every one of them is easy to game by someone who needs
the number to move, and the gaming damages the practice itself. They exist to tell the team whether
its own process is working.

## Measuring more

For anything beyond git history, such as how often hooks block actions, time spent waiting at
approval gates, or tool use per session, enable Claude Code's OpenTelemetry export and send it to
whatever monitoring system you already run. OpenTelemetry is a standard format for exporting logs,
metrics and traces. That export is where the Stage 5 figure for time spent waiting at each gate
comes from. It is also the number most likely to show where the real remaining bottleneck is once
the build is no longer the slowest step.
