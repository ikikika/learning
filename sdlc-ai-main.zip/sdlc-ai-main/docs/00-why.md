# Why this kit exists

## The problem it addresses

Writing code is no longer the slowest step in software delivery.

Most delivery processes in use today were designed when implementation took weeks. Planning, design,
review and release steps were sized to match. AI coding tools have cut implementation to hours, but
the steps around it have not changed. The slowest part of the process is now the human steps before
and after the build. A team that adopts AI coding tools and changes nothing else gets faster at the
one step that was not the problem, and the work then waits in a queue.

The answer is not to remove the human steps. It is to change what people spend their judgement on,
and to make the hand-offs between steps readable by both people and models, so that each step can
feed the next without manual translation.

## What changes in practice

**Documents become committed files.** A traditional requirements document is written for a person,
read once, and goes out of date. An `intent.md` is written for a person and for a model. It is
version-controlled, it shows up in diffs, and the next stage reads it as input. The information is
the same, but it stays useful for much longer.

**Review happens earlier.** Reviewing generated code is an expensive place to discover that the
approach was wrong. Reviewing a written plan before any code exists is a cheap place. Claude Code's
plan mode, in which Claude can read the repository but cannot edit anything until you approve a
written plan, makes this part of the tooling rather than a matter of discipline.

**Policy is applied while writing, not during review.** A security standard enforced by a reviewer
is applied inconsistently, weeks after the fact, by whoever happened to review that change. The same
standard written as a skill (a set of instructions Claude loads when the task matches) is applied
while the code is being written, every time, for everyone.

**Rules become executable.** "Never push from an agent session" written in a contributing guide is
followed only when people remember it. The same rule written as a hook (a script that runs before a
tool call and can block it) is applied every time. The difference between a rule that guides and a
rule that enforces is the most useful idea in the playbook, and most of this kit is built around it.

**The audit trail comes for free.** The intent, the specification, the plan, the code change and the
review findings are all commits, each with a timestamp and an author. There is no separate
compliance record to maintain, because doing the work produces the record.

## Why a kit rather than a document

Anthropic's [AI-Native SDLC Playbook](https://claude.com/blog/the-ai-native-sdlc-playbook) is the
source material, and it is good. But it is published as prose, and prose is applied inconsistently
in a large organisation. Each team reads it, agrees with it, and builds its own partial version with
its own file names. Six months later, nothing is comparable across teams, nothing is reusable, and
the second team to try starts from zero.

This repository turns the playbook into something you install. The installer is:

- **Safe to re-run.** Running it twice gives the same result as running it once. Running it after a
  kit upgrade updates only the files that changed.
- **Merging, not overwriting.** Target repositories already have a `CLAUDE.md` and a `settings.json`
  worth keeping. The installer adds to them and never rewrites them.
- **Modular.** You can adopt Stages 1 to 3 this quarter and Stage 6 next year. The stages are
  designed to be independent.
- **Profiled.** Merging into a main branch locally and merging through pull requests with branch
  protection are both valid ways to work. The kit supports both and asks you to choose one
  deliberately.

## What this kit deliberately does not do

- **It does not decide your policies.** The `secure-api-review` skill is an example. Your security
  standard is yours to write. The kit provides the shape of a policy skill and the mechanism that
  loads it.
- **It does not replace human judgement with automation.** Every stage keeps a decision that a named
  person makes.
- **It does not install enterprise controls.** `kit/enterprise/managed-settings.json` is deployed by
  IT through device management software, because a control that an engineer can edit does not
  control that engineer. See [`03-governance.md`](03-governance.md).

## Read next

1. [`01-stages.md`](01-stages.md) defines the terms. Read it before anything else.
2. [`02-adoption-path.md`](02-adoption-path.md) explains what to do in the first week.
3. [`../INSTALL.md`](../INSTALL.md) explains how to install the kit into a repository.
