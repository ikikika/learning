# AGENTS.md

The main guide for AI agents working in this repository is **[`CLAUDE.md`](CLAUDE.md)**. Read it
first.

Then read [`README.md`](README.md) for what this repository is,
[`docs/01-stages.md`](docs/01-stages.md) for the terms every other document uses, and
[`INSTALL.md`](INSTALL.md) for the guarantees the installer makes about not overwriting a user's
files.

This repository uses the kit it ships. Its own `CLAUDE.md` contains the same verification section
that the kit installs, and `make check` is the single verification command that section points to. A
completed set of artifacts (an intent, a specification and a plan for a real change) is in
[`examples/decision-layer/`](examples/decision-layer/).
